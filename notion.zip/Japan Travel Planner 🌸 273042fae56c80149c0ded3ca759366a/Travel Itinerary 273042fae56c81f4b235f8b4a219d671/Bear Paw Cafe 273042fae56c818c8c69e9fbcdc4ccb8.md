# Bear Paw Cafe

Group: Osaka
Day: Day 2
Type: Food
Notes: 5 PM
Description: Sun, Tues, Wed, Thurs: 11 AM–6:30 PM
Fri, Sat: 11 AM–7:30 PM
Mon: Closed
Credit card accepted
Visited: No

[Address: 5 Chome-3-11 Uehonmachinishi, Chuo Ward, Osaka, 542-0062, Japan](https://maps.app.goo.gl/aA5QL8UU7aq8qPMh8)

![Untitled](Bear%20Paw%20Cafe%20273042fae56c818c8c69e9fbcdc4ccb8/Untitled.png)