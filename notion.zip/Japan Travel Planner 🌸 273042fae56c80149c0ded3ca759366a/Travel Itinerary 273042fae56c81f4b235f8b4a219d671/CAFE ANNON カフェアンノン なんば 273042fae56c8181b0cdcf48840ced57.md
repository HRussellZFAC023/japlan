# CAFE ANNON カフェアンノン なんば

Group: Osaka
Day: Day 2
Type: Food
Notes: 4 PM

Description: Fluffy pancakes & parfaits
Credit card & reservations accepted
Visited: No
URL: https://cafe-annon.com/

[Address: 4-20 Nanbasennichimae, Chuo Ward, Osaka, 542-0075, Japan](https://maps.app.goo.gl/Y2AXk498PMgxdUDH6)

![Untitled](CAFE%20ANNON%20%E3%82%AB%E3%83%95%E3%82%A7%E3%82%A2%E3%83%B3%E3%83%8E%E3%83%B3%20%E3%81%AA%E3%82%93%E3%81%B0%20273042fae56c8181b0cdcf48840ced57/Untitled.png)