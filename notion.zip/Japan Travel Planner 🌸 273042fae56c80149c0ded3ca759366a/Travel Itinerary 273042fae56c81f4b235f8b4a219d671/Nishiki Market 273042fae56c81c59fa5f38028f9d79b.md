# Nishiki Market

Group: Kyoto
Day: Day 5
Type: Food
Notes: 3:30 PM
Description: 9AM-6PM
Fresh and preserved foods, duck specialties, Japanese sweets, and pickles
Visited: No

[Nakagyo Ward, Kyoto, 604-8055, Japan](https://maps.app.goo.gl/6tchB7v6v9ii5EK37)

![23041765_m-1.jpg](Nishiki%20Market%20273042fae56c81c59fa5f38028f9d79b/23041765_m-1.jpg)