# Takoume Honten (Oden)

Group: Osaka
Day: Day 1
Type: Food
Notes: 6 PM
Description: Oden
Visited: No

[Address: 1 Chome-1-8 Dotonbori, Chuo Ward, Osaka, 542-0071, Japan](https://maps.app.goo.gl/EYrbKtzwDdPfcm2w8)

![Untitled](Takoume%20Honten%20(Oden)%20273042fae56c81caaf84d5d88af272b9/Untitled.png)