# Shin Sekai "New World"

Group: Osaka
Day: Day 2
Type: Shopping
Notes: 8 PM
Description: Colorful district created in 1912 with a 103-m tower, restaurants & souvenir shops
Tower included in Osaka Amazing Pass
Visited: No

[Address: 2 Chome-5-1 Ebisuhigashi, Naniwa Ward, Osaka, 556-0002, Japan](https://maps.app.goo.gl/6fiNfvt3pJrzH9Gh7)

![Untitled](Shin%20Sekai%20New%20World%20273042fae56c813c9699dbf042edb352/Untitled.png)