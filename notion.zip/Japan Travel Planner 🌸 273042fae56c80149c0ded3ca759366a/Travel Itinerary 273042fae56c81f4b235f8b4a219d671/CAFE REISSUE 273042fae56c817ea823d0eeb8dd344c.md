# CAFE REISSUE

Group: Tokyo
Day: Day 6
Type: Food
Notes: 11 AM
Description: 2-D and 3-D cafe drinks
10 AM–7 PM, Monday closed
Cash only
Visited: Yes

[Address: 3 Chome-25-7 Jingumae, Shibuya City, Tokyo 150-0001, Japan](https://maps.app.goo.gl/8CERea4nJRV7FuAy5)

![Untitled](CAFE%20REISSUE%20273042fae56c817ea823d0eeb8dd344c/Untitled.png)