# Arashiyama Rilakkuma Tea House

Group: Kyoto
Day: Day 8
Type: Food
Notes: 11:30 AM
Description: Everyday 10:30 AM–5:30 PM
Rilakumma based tea house/cafe
Credit card accepted, 1650 yen
Visited: Yes

[15 Sagatenryuji Kitatsukurimichicho, Ukyo Ward, Kyoto, 616-8374, Japan](https://maps.app.goo.gl/3JKd5Vf2xxkTb1F4A)

![Screenshot 2024-06-21 at 11.18.38 AM.png](Arashiyama%20Rilakkuma%20Tea%20House%20273042fae56c81f2b32bf0ecac707ed8/Screenshot_2024-06-21_at_11.18.38_AM.png)