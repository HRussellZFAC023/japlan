# Tofu Cuisine Sorano Shibuya

Group: Tokyo
Day: Day 6
Type: Food
Notes: 9 PM
Description: Everything tofu
5 PM - 10:45 PM
Credit card accepted
Visited: No

[https://maps.app.goo.gl/HTD6F3L7egHxHdZs6](https://maps.app.goo.gl/HTD6F3L7egHxHdZs6)

![Screenshot 2024-06-21 at 11.33.07 AM.png](Tofu%20Cuisine%20Sorano%20Shibuya%20273042fae56c81379811ea09a7155b5b/Screenshot_2024-06-21_at_11.33.07_AM.png)