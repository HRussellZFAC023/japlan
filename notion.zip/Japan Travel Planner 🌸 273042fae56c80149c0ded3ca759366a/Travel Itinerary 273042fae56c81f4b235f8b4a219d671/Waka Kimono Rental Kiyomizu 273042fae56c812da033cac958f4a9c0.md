# Waka Kimono Rental Kiyomizu

Group: Kyoto
Day: Day 7
Type: Attractions
Description: No booking required
9 AM - 6 PM
Visited: Yes
URL: https://kyoto-photostudio.com/

[3 Chome-323-5 Kiyomizu, Higashiyama Ward, Kyoto, 605-0862, Japan](https://maps.app.goo.gl/daKsGA2UoBJPbY838)

![Untitled](Waka%20Kimono%20Rental%20Kiyomizu%20273042fae56c812da033cac958f4a9c0/Untitled.png)