# Osaka Castle

Group: Osaka
Day: Day 1
Type: Attractions
Notes: 9 AM
Description: 9AM-5PM
Entrance: $4.15
Revered castle dating to 1597 & since rebuilt, featuring gardens & a museum with varied exhibits
Visited: Yes

[1-1 Osakajo, Chuo Ward, Osaka, 540-0002, Japan](https://maps.app.goo.gl/yv9B2ujWQzHHEMS56)

![Untitled](Osaka%20Castle%20273042fae56c8136ae19db5b52755da4/Untitled.png)