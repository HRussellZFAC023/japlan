# Uniqlo Ginza

Group: Tokyo
Day: Day 3
Type: Shopping
Notes: 7 PM
Description: Biggest Uniqlo, 12 levels, connect to GU, customizable bags & shirts
11 AM–9 PM
Visited: No

[Japan, 〒104-0061 Tokyo, Chuo City, Ginza, 6 Chome−9−5 ギンザコマツ東館 1－12F](https://maps.app.goo.gl/BsP38Nuyva2UsCsf9)

![Untitled](Uniqlo%20Ginza%20273042fae56c81ef933ccf51dd5f991e/Untitled.png)