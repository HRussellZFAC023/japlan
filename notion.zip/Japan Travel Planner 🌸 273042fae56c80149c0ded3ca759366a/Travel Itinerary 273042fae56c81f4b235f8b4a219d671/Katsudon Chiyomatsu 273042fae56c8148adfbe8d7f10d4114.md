# Katsudon Chiyomatsu

Group: Osaka
Day: Day 2
Type: Food
Notes: 7:30 PM
Description: 11 AM–9 PM
Cash only
Visited: No

[Address: 1 Chome-1-10 Sennichimae, Chuo Ward, Osaka, 542-0074, Japan](https://maps.app.goo.gl/oj1aYDn1F3woSJ616)

![Untitled](Katsudon%20Chiyomatsu%20273042fae56c8148adfbe8d7f10d4114/Untitled.png)