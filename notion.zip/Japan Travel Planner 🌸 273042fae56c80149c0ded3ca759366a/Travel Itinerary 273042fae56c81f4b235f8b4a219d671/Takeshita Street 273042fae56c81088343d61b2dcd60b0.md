# Takeshita Street

Group: Tokyo
Day: Day 6
Type: Shopping
Notes: 1 PM
Description: Anime stores in Harajuku
Visited: Yes

[1 Chome Jingumae, Shibuya City, Tokyo 150-0001, Japan](https://maps.app.goo.gl/Xgf8ZzJ1dSZmULB66)

![Untitled](Takeshita%20Street%20273042fae56c81088343d61b2dcd60b0/Untitled.png)