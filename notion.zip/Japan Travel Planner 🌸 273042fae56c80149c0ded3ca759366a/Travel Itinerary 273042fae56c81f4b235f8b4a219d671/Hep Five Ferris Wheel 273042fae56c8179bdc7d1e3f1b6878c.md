# Hep Five Ferris Wheel

Group: Osaka
Day: Day 1
Type: Attractions
Notes: 3 PM
Description: 11AM-10:45PM
Entrance: $4.18
Visited: No

[Japan, 〒530-0017 Osaka, Kita Ward, Kakudacho, 5−15 HEP FIVE 7F](https://maps.app.goo.gl/TqpsiZWM9g2oJ9X8A)

![Untitled](Hep%20Five%20Ferris%20Wheel%20273042fae56c8179bdc7d1e3f1b6878c/Untitled.png)