# Sannenzaka Path

Group: Kyoto
Day: Day 7
Type: Attractions
Notes: 11:30 AM
Description: Stone-paved road with traditional buildings and shops
Visited: Yes

[Address: 2 Chome-211 Kiyomizu, Higashiyama Ward, Kyoto, 605-0862, Japan](https://maps.app.goo.gl/7jwJFmK33fpVXtDg7)

![Untitled](Sannenzaka%20Path%20273042fae56c81f7a0a6cb417d4b6b26/Untitled.png)