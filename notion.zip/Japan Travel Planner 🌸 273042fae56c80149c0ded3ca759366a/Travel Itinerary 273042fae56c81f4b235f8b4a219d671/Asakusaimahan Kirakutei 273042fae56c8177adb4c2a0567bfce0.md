# Asakusaimahan Kirakutei

Group: Tokyo
Day: Day 4
Type: Food
Notes: 6:30 PM
Description: sukiyaki (marbled wagyu beef for $28)
11 AM - 10 PM
Credit card accepted
Visited: No

[Japan, 〒160-0022 Tokyo, Shinjuku City, Shinjuku, 3 Chome−14−1 本館 7 伊勢丹新宿店](https://maps.app.goo.gl/GeviVah9MLqSxGgGA)

![Untitled](Asakusaimahan%20Kirakutei%20273042fae56c8177adb4c2a0567bfce0/Untitled.png)