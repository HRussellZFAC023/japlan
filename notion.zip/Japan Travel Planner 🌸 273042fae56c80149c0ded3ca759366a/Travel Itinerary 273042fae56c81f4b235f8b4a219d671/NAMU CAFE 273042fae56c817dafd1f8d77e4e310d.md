# NAMU CAFE

Group: Tokyo
Day: Day 6
Type: Food
Notes: 12 PM
Description: 11 AM–8 PM
Credit card accepted
Visited: Yes

[Japan, 〒150-0001 Tokyo, Shibuya City, Jingumae, 4 Chome−25−35 2F](https://maps.app.goo.gl/wa9jngMNK3XtENid9)

![Untitled](NAMU%20CAFE%20273042fae56c817dafd1f8d77e4e310d/Untitled.png)