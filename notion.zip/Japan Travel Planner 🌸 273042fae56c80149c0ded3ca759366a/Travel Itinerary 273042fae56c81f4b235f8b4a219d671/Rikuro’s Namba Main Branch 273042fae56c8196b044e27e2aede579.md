# Rikuro’s Namba Main Branch

Group: Osaka
Day: Day 1
Type: Food
Notes: 7 PM
Description: Fluffy pancakes
9AM-8PM
Visited: No

[Address: 3 Chome-2-28 Namba, Chuo Ward, Osaka, 542-0076, Japan](https://maps.app.goo.gl/9cTCM2ttxx1aBfUv9)

![Untitled](Rikuro%E2%80%99s%20Namba%20Main%20Branch%20273042fae56c8196b044e27e2aede579/Untitled.png)