# Bakery Bank

Group: Tokyo
Day: Day 3
Type: Food
Notes: 12:30 PM
Description: Curry bun + cafe
8 AM–6 PM (close on Wed)
credit card accepted
Visited: No

[Japan, 〒103-0026 Tokyo, Chuo City, Nihonbashikabutocho, 6−7 兜町第7平和ビル 1F](https://maps.app.goo.gl/dyyw97AUPUUvf6wc8)

![Untitled](Bakery%20Bank%20273042fae56c81a1b106c9715a8b7ccc/Untitled.png)