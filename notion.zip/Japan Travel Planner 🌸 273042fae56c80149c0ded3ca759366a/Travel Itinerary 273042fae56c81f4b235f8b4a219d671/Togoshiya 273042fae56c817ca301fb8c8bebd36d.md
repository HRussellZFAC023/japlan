# Togoshiya

Group: Tokyo
Day: Day 6
Type: Food
Notes: 9:30 PM
Description: 8 AM - 11 PM
Onigiri
Credit card accepted
Visited: No

[https://maps.app.goo.gl/DyFfXEkHtWwGUb68A](https://maps.app.goo.gl/DyFfXEkHtWwGUb68A)

![Screenshot 2024-06-21 at 11.29.45 AM.png](Togoshiya%20273042fae56c817ca301fb8c8bebd36d/Screenshot_2024-06-21_at_11.29.45_AM.png)