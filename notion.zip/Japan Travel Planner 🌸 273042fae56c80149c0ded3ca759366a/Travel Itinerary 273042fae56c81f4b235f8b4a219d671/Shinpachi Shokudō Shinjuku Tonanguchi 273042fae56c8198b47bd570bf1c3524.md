# Shinpachi Shokudō Shinjuku Tonanguchi

Group: Tokyo
Day: Day 4
Type: Food
Notes: 2:30 PM
Description: 4AM-3AM everyday
Visited: No

[3 Chome-35-5 Shinjuku, Shinjuku City, Tokyo 160-0022, Japan](https://maps.app.goo.gl/teLUUnYkXSWBmkQu7)

![Screenshot 2024-06-21 at 11.23.41 AM.png](Shinpachi%20Shokud%C5%8D%20Shinjuku%20Tonanguchi%20273042fae56c8198b47bd570bf1c3524/Screenshot_2024-06-21_at_11.23.41_AM.png)

![Screenshot 2024-06-21 at 11.23.32 AM.png](Shinpachi%20Shokud%C5%8D%20Shinjuku%20Tonanguchi%20273042fae56c8198b47bd570bf1c3524/Screenshot_2024-06-21_at_11.23.32_AM.png)