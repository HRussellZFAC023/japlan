# Godaime Hanayama Udon Nihonbashi

Group: Tokyo
Day: Day 3
Type: Food
Notes: 10 PM
Description: 11 AM–3:30 PM
5:30–9:30 PM

Credit card accepted
Visited: No

https://maps.app.goo.gl/GHQkZZ8MD8uMEF2M9?g_st=com.google.maps.preview.copy

![IMG_0010.jpeg](Godaime%20Hanayama%20Udon%20Nihonbashi%20273042fae56c81679f79e3ef25ee7030/IMG_0010.jpeg)