# Rice Ball "Onigiri" Gorichan

Group: Osaka
Type: Food
Visited: No

![Screenshot 2024-06-21 at 1.29.48 PM.png](Rice%20Ball%20Onigiri%20Gorichan%20273042fae56c814b830ccb8cd34a719b/Screenshot_2024-06-21_at_1.29.48_PM.png)

[https://maps.app.goo.gl/opBTHrqwMrPkXHXq8](https://maps.app.goo.gl/opBTHrqwMrPkXHXq8)