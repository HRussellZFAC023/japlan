# Gyukatsu Motomura

Group: Osaka
Day: Day 2
Type: Food
Notes: 1:30 PM
Description: Credit card accepted
Visited: Yes

![Screenshot 2024-06-21 at 1.35.26 PM.png](Gyukatsu%20Motomura%20273042fae56c81da930ee778b31d3aec/Screenshot_2024-06-21_at_1.35.26_PM.png)

[https://maps.app.goo.gl/gXYVh9nwxNe25nZV8](https://maps.app.goo.gl/gXYVh9nwxNe25nZV8)