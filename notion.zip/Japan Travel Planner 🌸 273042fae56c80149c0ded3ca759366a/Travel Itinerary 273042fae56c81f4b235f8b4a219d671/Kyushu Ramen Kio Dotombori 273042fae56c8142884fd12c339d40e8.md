# Kyushu Ramen Kio Dotombori

Group: Osaka
Type: Food
Notes: 11 AM–2 AM
Visited: No

[Address: Japan, 〒542-0071 Osaka, Chuo Ward, Dotonbori, 2 Chome−2−17 忠兵衛ビル 1F](https://maps.app.goo.gl/otFbvA3fmo6U9b6w5)

![Untitled](Kyushu%20Ramen%20Kio%20Dotombori%20273042fae56c8142884fd12c339d40e8/Untitled.png)