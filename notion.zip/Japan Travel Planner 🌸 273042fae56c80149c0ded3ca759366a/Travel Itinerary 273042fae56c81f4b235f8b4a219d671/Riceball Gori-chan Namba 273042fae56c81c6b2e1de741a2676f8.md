# Riceball Gori-chan Namba

Group: Osaka
Day: Day 1
Type: Food
Notes: 12 PM
Description: 11 AM–8 PM, closed on Tuesdays
350 yen, cash only
Visited: No

[Japan, 〒542-0081 Osaka, Chuo Ward, Minamisenba, 3 Chome−5−28 富士ビル南船場 1階](https://maps.app.goo.gl/TP9Zj5RoiWM7q39d8) (multiple locations)

![Untitled](Riceball%20Gori-chan%20Namba%20273042fae56c81c6b2e1de741a2676f8/Untitled.png)