# Abura Soba Kirinji Sennichimae

Group: Osaka
Type: Food
Notes: 8 PM
Description: Hours: 11:30 AM–12 AM
Cash only
Visited: No
URL: http://suzume-group.co.jp/

[Address: 1 Chome-4-15 Dotonbori, Chuo Ward, Osaka, 542-0071, Japan](https://maps.app.goo.gl/64tow3dcfc9DXiPR6)

![Untitled](Abura%20Soba%20Kirinji%20Sennichimae%20273042fae56c811bae2aca5e4a8ad798/Untitled.png)