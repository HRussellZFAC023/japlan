# Fushimi Inari Taisha

Group: Kyoto
Day: Day 5
Type: Attractions
Notes: 12:30 PM
Description: Free entrance
Visited: Yes

[Address: 68 Fukakusa Yabunouchicho, Fushimi Ward, Kyoto, 612-0882, Japan](https://maps.app.goo.gl/8U8EsjXe3Hd4e7WT7)

![Untitled](Fushimi%20Inari%20Taisha%20273042fae56c81ba87d1d18d202a23c4/Untitled.png)