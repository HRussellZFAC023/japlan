# Tokyo Metropolitan Government Building

Group: Tokyo
Day: Day 4
Type: Attractions
Notes: 8 PM
Description: 9:30 AM - 10:00 PM (entry until 9:30 PM)
Visited: No
URL: https://www.yokoso.metro.tokyo.lg.jp/en/tenbou/index.html

[Address: 2 Chome-8-1 Nishishinjuku, Shinjuku City, Tokyo 163-8001, Japan](https://maps.app.goo.gl/KLCzdhYYNQeo9SwB9)

[Light show info](https://tokyoprojectionmappingproject.jp/en/event/20240225/)

![Untitled](Tokyo%20Metropolitan%20Government%20Building%20273042fae56c81eca672d3c0118cdf7b/Untitled.png)