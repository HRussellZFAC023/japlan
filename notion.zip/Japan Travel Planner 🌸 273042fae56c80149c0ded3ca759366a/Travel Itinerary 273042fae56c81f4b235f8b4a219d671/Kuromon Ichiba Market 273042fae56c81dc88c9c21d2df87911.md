# Kuromon Ichiba Market

Group: Osaka
Day: Day 2
Type: Food
Notes: 6 PM
Description: Market with vendors selling street food, fresh produce & shellfish, souvenirs, cheap wagyu beef
Visited: No

[Address: 2 Chome Nipponbashi, Chuo Ward, Osaka, 542-0073, Japan](https://maps.app.goo.gl/KCuatjf2Ceh6ZpEM8)

![Untitled](Kuromon%20Ichiba%20Market%20273042fae56c81dc88c9c21d2df87911/Untitled.png)