# Arashiyama Miffy Sakura Kitchen

Group: Kyoto
Day: Day 8
Type: Food
Notes: 10 AM
Description: Everyday 10 AM–6 PM
Miffy cafe
Credit card accepted
Visited: Yes

[Japan, 〒616-8384 Kyoto, Ukyo Ward, Sagatenryuji Tsukurimichicho, 20 番 27](https://maps.app.goo.gl/WwHyr5rySc9QFQu29)

![Screenshot 2024-06-21 at 11.34.24 AM.png](Arashiyama%20Miffy%20Sakura%20Kitchen%20273042fae56c81b386d9e42e8def4408/Screenshot_2024-06-21_at_11.34.24_AM.png)