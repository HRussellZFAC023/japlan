# Namba Yasaka Shrine

Group: Osaka
Day: Day 2
Type: Attractions
Notes: 3 PM
Description: Hours: 9AM-5PM, free entrance
Small shrine featuring a ritualistic performance stage in the shape of a lion's head
Visited: No

[2 Chome-9-19 Motomachi, Naniwa Ward, Osaka, 556-0016, Japan](https://maps.app.goo.gl/huZ1yEUrXV4E4jzA9)

![Untitled](Namba%20Yasaka%20Shrine%20273042fae56c81d7820cff6e0e814ead/Untitled.png)