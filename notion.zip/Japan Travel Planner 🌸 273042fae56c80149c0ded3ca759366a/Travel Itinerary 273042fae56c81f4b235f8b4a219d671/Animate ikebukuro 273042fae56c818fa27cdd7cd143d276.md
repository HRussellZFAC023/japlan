# Animate ikebukuro

Group: Tokyo
Day: Day 4
Type: Shopping
Notes: 10:30 AM
Description: Biggest anime store in Tokyo
11 AM–8 PM
Visited: Yes

[Address: 1 Chome-20-7 Higashiikebukuro, Toshima City, Tokyo 170-0013, Japan](https://maps.app.goo.gl/9uRDAw3N4bvMS7gH8)

![Untitled](Animate%20ikebukuro%20273042fae56c818fa27cdd7cd143d276/Untitled.png)

![Untitled](Animate%20ikebukuro%20273042fae56c818fa27cdd7cd143d276/Untitled%201.png)