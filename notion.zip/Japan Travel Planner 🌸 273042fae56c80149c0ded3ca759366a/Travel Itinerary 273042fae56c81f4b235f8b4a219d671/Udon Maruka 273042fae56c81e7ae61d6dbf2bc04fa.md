# Udon Maruka

Group: Tokyo
Type: Food
Description: Saturday: 11 AM–2:30 PM
Sunday, Closed
Other days: 11 AM–4 PM, 5–7:30 PM
Visited: No

[Address: Japan, 〒101-0052 Tokyo, Chiyoda City, Kanda Ogawamachi, 3 Chome−１６−1 ニュー駿河台ビル 1F](https://maps.app.goo.gl/WUnSA2LCBM5SL29SA)

![Untitled](Udon%20Maruka%20273042fae56c81e7ae61d6dbf2bc04fa/Untitled.png)