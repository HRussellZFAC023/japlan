# Hello Donuts

Group: Tokyo
Day: Day 4
Type: Food
Notes: 1 PM
Description: 11 AM–10 PM
Credit card accepted
Visited: Yes

[서울 타운SEOULTOWN1F, 2 Chome-2-7 Hyakunincho, Shinjuku City, Tokyo 169-0073, Japan](https://maps.app.goo.gl/xWsrrZMutDihb5PHA)

![Untitled](Hello%20Donuts%20273042fae56c81caa06fd8df875927d6/Untitled.png)