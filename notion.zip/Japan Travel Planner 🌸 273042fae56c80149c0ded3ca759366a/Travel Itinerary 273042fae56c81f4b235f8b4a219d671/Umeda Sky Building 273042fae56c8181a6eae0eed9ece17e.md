# Umeda Sky Building

Group: Osaka
Day: Day 1
Type: Attractions
Notes: 4 PM
Description: 9:30AM-10:30PM, Entrance: $10.42
Connected skyscrapers with a rooftop garden observatory, plus a restaurant & lounge with city views
Visited: No

[1 Chome-1-88 Oyodonaka, Kita Ward, Osaka, 531-6023, Japan](https://maps.app.goo.gl/jchLrGhHPqLU2n2x5)

![1.jpg](Umeda%20Sky%20Building%20273042fae56c8181a6eae0eed9ece17e/1.jpg)