# Masahiko Ozumi Paris

Group: Osaka
Day: Day 1
Type: Food
Notes: 10 AM

Description: 10 AM–7 PM, Close on Weds 
950 yen Crochet donuts
Visited: Yes

[Address: Japan, 〒540-0021 Osaka, Chuo Ward, Otedori, 2 Chome−4−8 assess 大手通ビル1階](https://maps.app.goo.gl/n3MDNG46Y5rBpkeH8)

![Untitled](Masahiko%20Ozumi%20Paris%20273042fae56c81128094c23c7eff0b4c/Untitled.png)