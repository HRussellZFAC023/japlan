# Studio Ghibli Store

Group: Osaka
Day: Day 2
Type: Shopping
Notes: 1 PM
Description: Ghibli store
10 AM–8 PM
Visited: Yes

[Japan, 〒542-0085 Osaka, Chuo Ward, Shinsaibashisuji, 1 Chome−8−3 心斎橋PARCO 6F](https://maps.app.goo.gl/9ufnqQcHR53bGij46)

![Untitled](Studio%20Ghibli%20Store%20273042fae56c81758db0dabd33a380f5/fd8c38a9-c194-4566-8ef6-a39d156a5662.png)