# MACCHA HOUSE Kyoto Kawaramachi

Group: Kyoto
Type: Food
Description: 11 AM–8 PM
Matcha tea, coffee, ice cream, tiramisu
Visited: No

[Address: Japan, 〒604-8026 Kyoto, Nakagyo Ward, Komeyacho, 382‐2](https://maps.app.goo.gl/BNMZJo1P3nQRLFVC6)

![Untitled](MACCHA%20HOUSE%20Kyoto%20Kawaramachi%20273042fae56c8188aee7fcdd7141b220/Untitled.png)