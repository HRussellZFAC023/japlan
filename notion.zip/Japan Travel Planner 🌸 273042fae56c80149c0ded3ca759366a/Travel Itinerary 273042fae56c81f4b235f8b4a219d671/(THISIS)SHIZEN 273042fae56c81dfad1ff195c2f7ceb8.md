# (THISIS)SHIZEN

Group: Kyoto
Day: Day 5
Type: Food
Notes: 2:30 PM
Description: 10 AM–7 PM
Flower ice cream
Credit card accepted
Visited: No

[Address: Japan, 〒604-8172 Kyoto, Nakagyo Ward, Banocho, 586-2 新風館 1階 THISIS)SHIZEN](https://maps.app.goo.gl/Ry1t55vCt2jSfyft6)

![Untitled]((THISIS)SHIZEN%20273042fae56c81dfad1ff195c2f7ceb8/Untitled.png)