# Arashiyama Yoshimura

Group: Kyoto
Type: Food
Description: Everyday 11 AM–5 PM
Soba with good view
Visited: No

[Japan, 〒616-8385 Kyoto, Ukyo Ward, Sagatenryuji Susukinobabacho, ３](https://maps.app.goo.gl/Dkw5pcfqC6DWuWiz6)

![Screenshot 2024-06-21 at 11.27.57 AM.png](Arashiyama%20Yoshimura%20273042fae56c81b1af7febd146864b73/Screenshot_2024-06-21_at_11.27.57_AM.png)