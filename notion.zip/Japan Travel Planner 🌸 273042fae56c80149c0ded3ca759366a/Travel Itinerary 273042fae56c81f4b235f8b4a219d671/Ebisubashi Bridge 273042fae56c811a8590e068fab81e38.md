# Ebisubashi Bridge

Group: Osaka
Type: Attractions
Description: Gilco man
Visited: No

[1 Chome Dotonbori, Chuo Ward, Osaka, 542-0071, Japan](https://maps.app.goo.gl/RkQFS2pFCyd1vVy27)

![Untitled](Ebisubashi%20Bridge%20273042fae56c811a8590e068fab81e38/Untitled.png)