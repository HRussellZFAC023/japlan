# Kyoto Yakiniku Hiro Shijo Kiyamachi Branch

Group: Kyoto
Day: Day 7
Type: Food
Notes: 6 PM
Description: 5–11 PM
Credit card accepted
Visited: No
URL: https://yoyaku.toreta.in/yasaka/#/reserve-info

[https://maps.app.goo.gl/rknV6vT4JdbWXGmd8](https://maps.app.goo.gl/rknV6vT4JdbWXGmd8)

![Untitled](Kyoto%20Yakiniku%20Hiro%20Shijo%20Kiyamachi%20Branch%20273042fae56c81f18467dfb144be0581/Untitled.png)