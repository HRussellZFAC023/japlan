# Unitora Nakadori

Group: Tokyo
Day: Day 3
Type: Food
Notes: 8 PM
Description: Uni bowls at Tsukiji Outer Market
7 AM–9 PM
Cash only
Visited: No

[Japan, 〒104-0045 Tokyo, Chuo City, Tsukiji, 4 Chome−10−5 カネシン水産ビル 1F](https://maps.app.goo.gl/wvGg2JEwQevcSjJ26)

![Untitled](Unitora%20Nakadori%20273042fae56c811bb1aedafe59f9198c/Untitled.png)