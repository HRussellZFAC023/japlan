# Shinsekai

Group: Osaka
Type: Attractions
Description: Trendy retro district
Visited: No

[3 Chome-2-27 Ebisuhigashi, Naniwa Ward, Osaka, 556-0002, Japan](https://maps.app.goo.gl/qbdmu1F5DozyfgLq6)

![Untitled](Shinsekai%20273042fae56c814b9bf3f4a11a2bb62c/Untitled.png)