# Ikeda-ya TeaStore

Group: Tokyo
Day: Day 4
Notes: 11 AM
Description: Matcha store
Visited: Yes

Japan, 〒160-0023 Tokyo, Shinjuku City, Nishishinjuku, 1 Chome−1, 小田急エース

[https://maps.app.goo.gl/3pMhNcpUxz6C2Pwv8?g_st=com.google.maps.preview.copy](https://maps.app.goo.gl/3pMhNcpUxz6C2Pwv8?g_st=com.google.maps.preview.copy)

![Screenshot 2024-08-28 at 1.37.18 PM.png](Ikeda-ya%20TeaStore%20273042fae56c81d8a99ed697ffb0c7cc/Screenshot_2024-08-28_at_1.37.18_PM.png)