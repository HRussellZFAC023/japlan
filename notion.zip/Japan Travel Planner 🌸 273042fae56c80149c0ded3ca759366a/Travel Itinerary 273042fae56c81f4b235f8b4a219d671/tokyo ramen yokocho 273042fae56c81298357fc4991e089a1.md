# tokyo ramen yokocho

Group: Tokyo
Day: Day 3
Type: Food
Notes: 12 PM
Description: Small ramen shop near Tokyo Station Ramen Alley
11 AM–11 PM
Credit card accepted
Visited: No

[Japan, 〒104-0028 Tokyo, Chuo City, Yaesu, 2 Chome−1 1号 地下街北 B1階](https://maps.app.goo.gl/wTrKvPvZK5LUCspw5)

![Untitled](tokyo%20ramen%20yokocho%20273042fae56c81298357fc4991e089a1/Untitled.png)