# Kura Sushi Namba-Motomachi Store

Group: Osaka
Type: Food
Description: Conveyer belt affordable sushi

Mon: 11AM-10PM
Tues, Wed, Sat: 10:20AM-12AM
Thurs, Fri: 11 AM–12 AM
Sun: 10:20AM-9PM
Visited: No

[Address: 1 Chome-8-23 Shikitsuhigashi, Naniwa Ward, Osaka, 556-0012, Japan](https://maps.app.goo.gl/aqK3yHwazhjJJA8d7)

![Untitled](Kura%20Sushi%20Namba-Motomachi%20Store%20273042fae56c8158bc73cb34b5997a6d/Untitled.png)