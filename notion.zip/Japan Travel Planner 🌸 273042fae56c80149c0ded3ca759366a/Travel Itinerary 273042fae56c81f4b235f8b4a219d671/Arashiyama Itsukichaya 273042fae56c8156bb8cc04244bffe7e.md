# Arashiyama Itsukichaya

Group: Kyoto
Day: Day 8
Type: Food
Notes: 2 PM
Visited: No
URL: https://www.tablecheck.com/en/shops/itsukichaya/reserve

[Address: Japan, 〒616-8383 Kyoto, Ukyo Ward, Saganakanoshimacho, 官有地10](https://maps.app.goo.gl/atY5MDppwLndJTY8A)

![Untitled](Arashiyama%20Itsukichaya%20273042fae56c8156bb8cc04244bffe7e/Untitled.png)