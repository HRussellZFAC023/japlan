# Shibuya Crossing

Group: Tokyo
Day: Day 6
Type: Attractions
Notes: 2 PM
Visited: No

[Address: Shibuya City, Tokyo, Japan](https://maps.app.goo.gl/MUtHWnu5D4CcmUZQ7)

![Untitled](Shibuya%20Crossing%20273042fae56c8165a913d0ff7e52a593/Untitled.png)