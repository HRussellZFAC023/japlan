# Heian Shrine

Group: Kyoto
Day: Day 5
Type: Attractions
Notes: 10:30 AM
Description: Free admission, 6AM-5PM
Classic Shinto shrine & landscaped gardens created in 1895 for the city's 1,100th birthday
Visited: Yes

[97 Okazaki Nishitennocho, Sakyo Ward, Kyoto, 606-8341, Japan](https://maps.app.goo.gl/MBFTHCn6bYrjDLoG8)

![heian_jingu-scaled.jpeg](Heian%20Shrine%20273042fae56c81ebadf6c495a03e560c/heian_jingu-scaled.jpeg)