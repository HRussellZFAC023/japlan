# Shunsai Imari

Group: Kyoto
Day: Day 5
Type: Food
Notes: 9 AM
Description: breakfast sets
Everyday except Tues 7:30–9:30 AM, 5:30–10:30 PM
Credit card accepted
Visited: Yes

[108 Nishirokkakucho, Nakagyo Ward, Kyoto, 604-8217, Japan](https://maps.app.goo.gl/Dd53nRtxzDUjhc5L8)

![Screenshot 2024-06-21 at 11.26.24 AM.png](Shunsai%20Imari%20273042fae56c814bb8b2fca14ee42062/Screenshot_2024-06-21_at_11.26.24_AM.png)