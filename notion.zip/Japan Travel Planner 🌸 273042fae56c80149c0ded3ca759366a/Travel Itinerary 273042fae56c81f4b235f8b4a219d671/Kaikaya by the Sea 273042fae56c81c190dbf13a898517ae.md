# Kaikaya by the Sea

Group: Tokyo
Day: Day 6
Type: Food
Notes: 10 PM
Description: 5 PM–10:30 PM, close on Wed
Credit card accepted
Visited: No

[23-7 Maruyamacho, Shibuya City, Tokyo 150-0044, Japan](https://maps.app.goo.gl/8qPqEw1A4XpPCEPUA)

![Untitled](Kaikaya%20by%20the%20Sea%20273042fae56c81c190dbf13a898517ae/Untitled.png)