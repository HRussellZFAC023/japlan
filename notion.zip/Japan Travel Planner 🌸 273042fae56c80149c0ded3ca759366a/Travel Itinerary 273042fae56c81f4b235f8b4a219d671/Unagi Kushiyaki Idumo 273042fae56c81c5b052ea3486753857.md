# Unagi Kushiyaki Idumo

Group: Osaka
Day: Day 1
Type: Food
Notes: 11 AM

Description: Unadon (grilled eel rice bowl)
11 AM–10 PM
Visited: Yes
URL: https://tabelog.com/osaka/A2701/A270101/27101583/

[Address: Japan, 〒530-0001 Osaka, Kita Ward, Umeda, 3 Chome−1−3 ルクアバルチカ地下 2階](https://maps.app.goo.gl/VnNzBywUuMiShTWAA)

![Untitled](Unagi%20Kushiyaki%20Idumo%20273042fae56c81c5b052ea3486753857/Untitled.png)