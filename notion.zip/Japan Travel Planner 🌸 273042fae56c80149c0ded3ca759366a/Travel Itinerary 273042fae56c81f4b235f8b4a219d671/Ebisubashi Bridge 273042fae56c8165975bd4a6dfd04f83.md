# Ebisubashi Bridge

Group: Osaka
Day: Day 1
Type: Shopping
Notes: 9 PM
Description: Osaka’s main shopping area and Glico Man
Visited: No

[1 Chome Dotonbori, Chuo Ward, Osaka, 542-0071, Japan](https://maps.app.goo.gl/huNaHNS3UXCGSk6u7)

![Untitled](Ebisubashi%20Bridge%20273042fae56c8165975bd4a6dfd04f83/Untitled.png)