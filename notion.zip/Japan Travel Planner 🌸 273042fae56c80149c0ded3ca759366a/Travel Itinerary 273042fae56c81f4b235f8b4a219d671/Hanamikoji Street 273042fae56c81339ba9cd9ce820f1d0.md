# Hanamikoji Street

Group: Kyoto
Day: Day 7
Type: Shopping
Notes: 2:30 PM
Description: Historic district with traditional buildings, kimono shops, restaurants & geisha
Visited: No

[Address: Gionmachi Minamigawa, Kyoto, 600-8340, Japan](https://maps.app.goo.gl/fDJkmocG4UcnxB9N6)

![Untitled](Hanamikoji%20Street%20273042fae56c81339ba9cd9ce820f1d0/Untitled.png)