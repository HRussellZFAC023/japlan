# Cup Noodles Museum

Group: Osaka
Day: Day 2
Type: Attractions
Notes: 10:30 AM
Description: Customize your ramen, free entrance
Hours: 9:30 AM–4:30 PM
Visited: Yes
URL: https://www.cupnoodles-museum.jp/en/osaka_ikeda/

[8-25 Masumicho, Ikeda, Osaka 563-0041, Japan](https://maps.app.goo.gl/Dg649uZCoR6y7oLr7)

![Untitled](Cup%20Noodles%20Museum%20273042fae56c817c82c8e55dca63ecf7/Untitled.png)