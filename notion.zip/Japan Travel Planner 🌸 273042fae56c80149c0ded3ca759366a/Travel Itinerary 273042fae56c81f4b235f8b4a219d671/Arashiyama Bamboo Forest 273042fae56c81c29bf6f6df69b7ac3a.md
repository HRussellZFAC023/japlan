# Arashiyama Bamboo Forest

Group: Kyoto
Day: Day 8
Type: Attractions
Notes: 12:30 PM
Visited: Yes

[Address: Sagaogurayama Tabuchiyamacho, Ukyo Ward, Kyoto, 616-8394, Japan](https://maps.app.goo.gl/Jb3F3Q4Y9sYfLHSk6)

![arashiyama.jpg](Arashiyama%20Bamboo%20Forest%20273042fae56c81c29bf6f6df69b7ac3a/arashiyama.jpg)