# Tokyo Character Street

Group: Tokyo
Day: Day 3
Type: Shopping
Notes: 1 PM
Description: Inside Tokyo Station with stores for anime and manga character merchandise, official plushies
10:00 AM - 8:30 PM
Visited: No

[**Address:** First Avenue Tokyo Station B1, 1 Chome-9-1 Marunouchi, Chiyoda City, Tokyo 100-0005, Japan](https://maps.app.goo.gl/T4VYv31qv5UmuxyG8)

![Untitled](Tokyo%20Character%20Street%20273042fae56c81d68354c9ea348eeb0b/Untitled.png)