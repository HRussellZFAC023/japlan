# Power Adaptor

Type: Electronics
Packed: No
Quantity: 2