# Headphones

Type: Electronics
Notes: Storage case
Packed: No
Quantity: 1