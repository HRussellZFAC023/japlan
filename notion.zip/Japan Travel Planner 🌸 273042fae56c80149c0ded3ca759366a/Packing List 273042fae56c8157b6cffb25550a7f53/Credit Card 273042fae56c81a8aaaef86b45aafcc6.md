# Credit Card

Type: Electronics
Packed: No
Quantity: 1