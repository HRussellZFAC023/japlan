# Hair Brush

Type: Toiletries
Packed: No
Quantity: 1