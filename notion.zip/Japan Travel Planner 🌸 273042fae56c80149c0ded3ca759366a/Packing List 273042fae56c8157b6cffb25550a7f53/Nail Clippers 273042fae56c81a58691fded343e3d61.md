# Nail Clippers

Type: Toiletries
Packed: No
Quantity: 1