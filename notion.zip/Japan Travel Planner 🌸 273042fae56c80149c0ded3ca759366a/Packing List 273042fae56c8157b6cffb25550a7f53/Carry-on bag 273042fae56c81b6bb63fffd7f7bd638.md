# Carry-on bag

Type: Essentials
Packed: No
Quantity: 1