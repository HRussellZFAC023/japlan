# Water bottle

Type: Essentials
Packed: No
Quantity: 1