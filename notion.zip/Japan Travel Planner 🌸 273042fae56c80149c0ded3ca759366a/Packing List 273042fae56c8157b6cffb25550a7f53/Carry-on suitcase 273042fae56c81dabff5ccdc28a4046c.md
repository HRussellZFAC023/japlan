# Carry-on suitcase

Type: Essentials
Packed: No
Quantity: 1