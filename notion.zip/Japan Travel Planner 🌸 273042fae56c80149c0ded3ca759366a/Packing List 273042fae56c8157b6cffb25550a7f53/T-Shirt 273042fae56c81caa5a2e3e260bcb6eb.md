# T-Shirt

Type: Clothes
Packed: No
Quantity: 5