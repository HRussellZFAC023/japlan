# Hotel in Tokyo

Transaction Amount: $135.00
Category: Accommodation
Comment: 3 nights
Date: January 8, 2025