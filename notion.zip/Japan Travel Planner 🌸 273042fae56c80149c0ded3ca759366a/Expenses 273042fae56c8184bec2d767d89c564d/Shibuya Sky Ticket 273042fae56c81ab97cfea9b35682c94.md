# Shibuya Sky Ticket

Transaction Amount: $15.72
Category: Entertainment
Comment: Booked for 5 pm slot
Date: January 8, 2025