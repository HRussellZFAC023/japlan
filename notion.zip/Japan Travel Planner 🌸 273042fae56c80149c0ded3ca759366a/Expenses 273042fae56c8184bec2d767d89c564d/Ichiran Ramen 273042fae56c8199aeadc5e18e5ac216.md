# Ichiran Ramen

Transaction Amount: $7.85
Category: Dining
Date: January 12, 2025