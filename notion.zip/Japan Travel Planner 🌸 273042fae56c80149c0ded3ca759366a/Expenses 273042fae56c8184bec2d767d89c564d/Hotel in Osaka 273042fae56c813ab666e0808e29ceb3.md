# Hotel in Osaka

Transaction Amount: $118.63
Category: Accommodation
Comment: 2 nights
Date: January 6, 2025