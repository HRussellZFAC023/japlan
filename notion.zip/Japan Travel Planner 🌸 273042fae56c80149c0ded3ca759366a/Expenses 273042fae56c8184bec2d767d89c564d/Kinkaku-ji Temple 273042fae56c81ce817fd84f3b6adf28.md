# Kinkaku-ji Temple

Transaction Amount: $3.56
Category: Ticket
Date: January 12, 2025