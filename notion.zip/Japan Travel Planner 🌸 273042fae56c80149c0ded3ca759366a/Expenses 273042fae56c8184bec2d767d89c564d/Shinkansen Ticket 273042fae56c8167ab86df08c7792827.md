# Shinkansen Ticket

Transaction Amount: $98.63
Category: Transportation
Comment: 8 am departure
Date: January 28, 2025
URL: https://travel.japanrailpassnow.com/en-US/activity/1420-7-day-whole-japan-rail-pass-jr-pass/?aid=35290&utm_medium=affiliate-alwayson&utm_source=non-network&utm_campaign=35290&utm_term=