# Hotel in Kyoto

Transaction Amount: $120.00
Category: Accommodation
Comment: 2 nights
Date: January 7, 2025