# Plane ticket to Japan

Transaction Amount: $562.10
Category: Ticket
Comment: Make sure to check-in within 48 hours before departure
Date: January 1, 2025