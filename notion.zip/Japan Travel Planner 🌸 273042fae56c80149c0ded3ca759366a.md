# Japan Travel Planner 🌸

## Japan Places to Visit 🍡

[Untitled](Japan%20Travel%20Planner%20%F0%9F%8C%B8%20273042fae56c80149c0ded3ca759366a/Untitled%20273042fae56c81beb5c6dd05945c9506.csv)

### To-Dos 📝

---

- [ ]  Book flight tickets
- [ ]  Book accommodations
- [ ]  Create packing list
- [ ]  Plan travel itinerary
- [ ]  Make restaurant and attraction reservations
- [ ]  Purchase transportation passes
- [ ]  Purchase e-Sim
- [ ]  Learn basic Japanese phrases to navigate around

---

## Links 🔗

- Japan trip Google Map
- Japan trip Google Doc

---

## 

## Travel Itinerary 📅

[Travel Itinerary](Japan%20Travel%20Planner%20%F0%9F%8C%B8%20273042fae56c80149c0ded3ca759366a/Travel%20Itinerary%20273042fae56c81f4b235f8b4a219d671.csv)

## Packing List 💼

[Packing List](Japan%20Travel%20Planner%20%F0%9F%8C%B8%20273042fae56c80149c0ded3ca759366a/Packing%20List%20273042fae56c8157b6cffb25550a7f53.csv)

# Expenses Tracker💰

[Expenses](Japan%20Travel%20Planner%20%F0%9F%8C%B8%20273042fae56c80149c0ded3ca759366a/Expenses%20273042fae56c8184bec2d767d89c564d.csv)

---


## Constraints (locked & guiding)
- **Flights**: Arrive **Fri 14 Nov** (KIX), Depart **Sun 30 Nov** (KIX).
- **Base**: Osaka (Hirakata) — prefer hotels near Hirakatashi on Nana’s **Tue/Fri** work days.
- **Nana**: Works **Tuesdays & Fridays**; **max 3 consecutive** days off; can stay with you most nights if logistics allow.
- **Friends**: Nicole & Ken (Tokyo/Chiba, join in Tokyo + Osaka birthday); James (Tokyo only, evenings/weekend).
- **Birthday**: **Fri 28 Nov** in Osaka — Nana + Nicole + Ken invited.
- **Bookings to secure**: Disney, USJ, teamLab, (Ghibli if available), themed café.


## Trip Plan — Draft (Nov 14–30, 2025)

| Date | Day | City | Highlights | With |
|---|---|---|---|---|
| Fri 14 Nov | Day 1 | Arrive KIX → Hirakata; Dōtonbori dinner | Arrive KIX → Hirakata; Dōtonbori dinner | Nana |
| Sat 15 Nov | Day 2 | Kyoto | Kyoto: Arashiyama → Kiyomizu → Fushimi Inari | Nana |
| Sun 16 Nov | Day 3 | Nara + Uji tea | Nara + Uji tea | Nana |
| Mon 17 Nov | Day 4 | Kōyasan Eko-in stay + Okunoin night tour | Kōyasan Eko-in stay + Okunoin night tour | Nana |
| Tue 18 Nov | Day 5 | Cup Noodles Ikeda; Shinsaibashi/Amemura (Nana work) | Cup Noodles Ikeda; Shinsaibashi/Amemura (Nana work) | Nana (work day) |
| Wed 19 Nov | Day 6 | Arima Onsen; Kobe Harborland | Arima Onsen; Kobe Harborland | Nana |
| Thu 20 Nov | Day 7 | Umeda Sky sunset | Umeda Sky sunset | Nana |
| Fri 21 Nov | Day 8 | Abeno Harukas (Nana work) | Abeno Harukas (Nana work) | Nana (work day) |
| Sat 22 Nov | Day 9 | Tokyo Disney day + Disney Hotel | Tokyo Disney day + Disney Hotel | Nana |
| Sun 23 Nov | Day 10 | teamLab → Collab café → Karaoke; Airbnb sleepover | teamLab → Collab café → Karaoke; Airbnb sleepover | Nicole, Ken (+ you) |
| Mon 24 Nov | Day 11 | Shibuya/Harajuku + meet James | Shibuya/Harajuku + meet James | Nicole, Ken, James |
| Tue 25 Nov | Day 12 | Shinkansen back to Osaka (Nana work) | Shinkansen back to Osaka (Nana work) | Nana (work day) |
| Wed 26 Nov | Day 13 | Himeji Castle + Kōko-en | Himeji Castle + Kōko-en | — |
| Thu 27 Nov | Day 14 | USJ | USJ — Super Nintendo World | Nana |
| Fri 28 Nov | Day 15 | Osaka birthday dinner + karaoke | Osaka birthday dinner + karaoke | Nana (+ Nicole & Ken) |
| Sat 29 Nov | Day 16 | Kyoto foliage finale (Eikan-dō/Tofuku-ji) | Kyoto foliage finale (Eikan-dō/Tofuku-ji) | Nana |
| Sun 30 Nov | Day 17 | Pack → KIX late flight | Pack → KIX late flight | Nana |