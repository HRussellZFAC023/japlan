# Kyomachiya Ryokan Sakura Urushitei

Transaction Amount: £216.22
Category: Lodging
Comment: Includes kaiseki dinner + breakfast. City: Kyoto Type: Ryokan Status: To Book
Date: November 19, 2025
