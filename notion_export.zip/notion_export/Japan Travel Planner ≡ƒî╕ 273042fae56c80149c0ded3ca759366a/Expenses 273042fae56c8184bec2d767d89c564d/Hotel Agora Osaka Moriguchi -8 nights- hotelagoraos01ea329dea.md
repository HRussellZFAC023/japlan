# Hotel Agora Osaka Moriguchi (8 nights)

Transaction Amount: £1,037.84
Category: Lodging
Comment: Bundle breakfast on work days; flexible cancellation until Nov 1. City: Osaka Type: Hotel Status: Reserve in Aug
Date: November 14, 2025
