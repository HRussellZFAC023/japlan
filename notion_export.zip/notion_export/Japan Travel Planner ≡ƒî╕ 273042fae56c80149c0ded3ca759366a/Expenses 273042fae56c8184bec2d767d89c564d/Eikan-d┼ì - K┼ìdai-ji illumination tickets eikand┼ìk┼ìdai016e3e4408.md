# Eikan-dō & Kōdai-ji illumination tickets

Transaction Amount: £43.24
Category: Experiences
Comment: Includes combo ticket for Entoku-in. City: Kyoto Type: Night Illumination Status: To Book
Date: November 29, 2025
