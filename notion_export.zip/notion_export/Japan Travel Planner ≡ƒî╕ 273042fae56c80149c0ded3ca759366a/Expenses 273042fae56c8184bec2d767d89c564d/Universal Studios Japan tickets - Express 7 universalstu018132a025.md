# Universal Studios Japan tickets + Express 7

Transaction Amount: £562.16
Category: Experiences
Comment: Pair with Super Nintendo timed entry + Kinopio’s Café lunch. City: Osaka Type: Theme Park Status: To Book
Date: November 27, 2025
