# Kansai Thru Pass (3-day) + Keihan upgrades

Transaction Amount: £54.05
Category: Transport
Comment: Covers Kyoto/Nara/Kobe days; add limited express seats as needed. City: Osaka/Kyoto Type: Rail Status: To Buy
Date: November 15, 2025
