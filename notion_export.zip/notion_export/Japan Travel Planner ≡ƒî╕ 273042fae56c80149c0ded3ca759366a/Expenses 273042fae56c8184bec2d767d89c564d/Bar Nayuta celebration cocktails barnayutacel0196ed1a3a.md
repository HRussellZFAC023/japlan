# Bar Nayuta celebration cocktails

Transaction Amount: £86.49
Category: Nightlife
Comment: Custom drink “Japlan Nova” + round of yuzu fizzes. City: Osaka Type: Cocktail Bar Status: Budget
Date: November 28, 2025
