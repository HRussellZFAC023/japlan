# Gekkeikan Sake tasting flight

Transaction Amount: £10.81
Category: Experiences
Comment: Add museum entry + bottle shipping. City: Kyoto Type: Tasting Status: To Pay
Date: November 16, 2025
