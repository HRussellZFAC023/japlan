# MIMARU Tokyo Shinjuku WEST

Transaction Amount: £194.59
Category: Lodging
Comment: Sleepover suite for 4 with breakfast hamper. City: Tokyo Type: Apartment Hotel Status: To Book
Date: November 23, 2025
