# sequence MIYASHITA PARK

Transaction Amount: £140.54
Category: Lodging
Comment: Ask for park-view room; deposit refundable until Nov 15. City: Tokyo Type: Hotel Status: To Book
Date: November 22, 2025
