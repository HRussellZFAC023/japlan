# Foodie highlights fund (markets & street eats)

Transaction Amount: £324.32
Category: Food & Drink
Comment: Kuromon, Nishiki, Tsukiji outer market, Harajuku snacks. City: Osaka/Kyoto/Tokyo Type: Daily Meals Status: Budget
Date: November 15, 2025
