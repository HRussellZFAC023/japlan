# Shibuya Sky tickets

Transaction Amount: £59.46
Category: Experiences
Comment: 17:00 sunset slot for 5 (including James). City: Tokyo Type: Viewpoint Status: To Book
Date: November 22, 2025
