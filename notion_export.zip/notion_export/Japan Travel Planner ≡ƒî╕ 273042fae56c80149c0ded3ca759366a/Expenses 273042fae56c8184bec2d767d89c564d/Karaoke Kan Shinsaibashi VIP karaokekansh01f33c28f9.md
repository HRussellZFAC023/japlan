# Karaoke Kan Shinsaibashi VIP

Transaction Amount: £129.73
Category: Nightlife
Comment: 3-hour premium room with open bar + props. City: Osaka Type: Entertainment Status: To Book
Date: November 28, 2025
