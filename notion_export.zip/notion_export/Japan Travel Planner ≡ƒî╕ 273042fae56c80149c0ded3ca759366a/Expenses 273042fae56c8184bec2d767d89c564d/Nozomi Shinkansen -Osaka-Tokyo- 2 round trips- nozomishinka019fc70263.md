# Nozomi Shinkansen (Osaka↔Tokyo, 2 round trips)

Transaction Amount: £302.70
Category: Transport
Comment: Outbound Nov 22, return Nov 24; Nicole & Ken return leg Nov 28. City: Tokyo Type: Rail Status: To Book
Date: November 22, 2025
