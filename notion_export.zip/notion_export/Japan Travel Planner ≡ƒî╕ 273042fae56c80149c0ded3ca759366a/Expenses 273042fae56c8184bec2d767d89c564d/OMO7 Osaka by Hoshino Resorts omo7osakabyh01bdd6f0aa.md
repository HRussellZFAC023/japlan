# OMO7 Osaka by Hoshino Resorts

Transaction Amount: £172.97
Category: Lodging
Comment: Add onsen access + late checkout request. City: Osaka Type: Hotel Status: To Book
Date: November 20, 2025
