# MYDO Teppanyaki birthday dinner

Transaction Amount: £324.32
Category: Food & Drink
Comment: Set menu for four + dessert sparkler. City: Osaka Type: Fine Dining Status: To Book
Date: November 28, 2025
