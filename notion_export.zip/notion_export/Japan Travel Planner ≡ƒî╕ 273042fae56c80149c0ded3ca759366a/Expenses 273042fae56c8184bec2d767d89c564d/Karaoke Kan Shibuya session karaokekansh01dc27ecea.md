# Karaoke Kan Shibuya session

Transaction Amount: £97.30
Category: Nightlife
Comment: 3-hour all-you-can-drink plan for four. City: Tokyo Type: Entertainment Status: To Book
Date: November 23, 2025
