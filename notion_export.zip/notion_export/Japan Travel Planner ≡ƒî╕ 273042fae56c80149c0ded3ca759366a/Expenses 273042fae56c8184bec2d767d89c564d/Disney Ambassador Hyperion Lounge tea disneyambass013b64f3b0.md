# Disney Ambassador Hyperion Lounge tea

Transaction Amount: £86.49
Category: Food & Drink
Comment: Afternoon tea for four with birthday plating. City: Tokyo Type: Tea Service Status: To Book
Date: November 24, 2025
