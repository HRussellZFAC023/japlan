# Pokémon Café prepayment

Transaction Amount: £64.86
Category: Experiences
Comment: Reservation deposit for four + souvenir mugs. City: Tokyo Type: Character Dining Status: To Book
Date: November 23, 2025
