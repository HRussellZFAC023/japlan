# Taxi & rideshare buffer

Transaction Amount: £81.08
Category: Transport
Comment: Kyoto tea ceremony transfers, late-night Osaka rides. City: Kyoto/Osaka/Tokyo Type: Transport Status: Budget
Date: November 19, 2025
