# Umeda Sky Building Observatory

Transaction Amount: £32.43
Category: Experiences
Comment: Includes cocktails at Sky 40 bar. City: Osaka Type: Viewpoint Status: To Book
Date: November 20, 2025
