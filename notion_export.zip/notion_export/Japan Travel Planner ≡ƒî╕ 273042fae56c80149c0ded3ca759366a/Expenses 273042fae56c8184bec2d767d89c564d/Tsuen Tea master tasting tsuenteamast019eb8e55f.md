# Tsuen Tea master tasting

Transaction Amount: £27.03
Category: Experiences
Comment: Reserve counter seats; includes souvenirs. City: Uji Type: Workshop Status: To Book
Date: November 17, 2025
