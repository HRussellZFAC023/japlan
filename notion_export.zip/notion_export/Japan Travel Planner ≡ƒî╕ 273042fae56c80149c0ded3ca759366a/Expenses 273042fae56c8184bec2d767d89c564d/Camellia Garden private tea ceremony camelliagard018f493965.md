# Camellia Garden private tea ceremony

Transaction Amount: £64.86
Category: Experiences
Comment: Private session for two with English host. City: Kyoto Type: Workshop Status: To Book
Date: November 19, 2025
