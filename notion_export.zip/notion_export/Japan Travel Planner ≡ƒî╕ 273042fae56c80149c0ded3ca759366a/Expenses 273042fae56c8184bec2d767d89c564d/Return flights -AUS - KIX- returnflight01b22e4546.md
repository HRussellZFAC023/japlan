# Return flights (AUS → KIX)

Transaction Amount: £1,297.30
Category: Transport
Comment: Redeemed partial points; cash component to be settled in Oct 2025. City: International Type: Flight Status: Booked
Date: November 14, 2025
