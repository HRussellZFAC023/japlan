# Arima Onsen Taiko-no-yu passes

Transaction Amount: £43.24
Category: Experiences
Comment: Includes private tatami lounge upgrade. City: Kobe Type: Wellness Status: To Pay
Date: November 26, 2025
