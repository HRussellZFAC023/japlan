# Haruka Express + ICOCA bundle (2 pax)

Transaction Amount: £56.22
Category: Transport
Comment: Purchase at KIX JR desk on arrival. City: Osaka Type: Rail Status: To Buy
Date: November 14, 2025
