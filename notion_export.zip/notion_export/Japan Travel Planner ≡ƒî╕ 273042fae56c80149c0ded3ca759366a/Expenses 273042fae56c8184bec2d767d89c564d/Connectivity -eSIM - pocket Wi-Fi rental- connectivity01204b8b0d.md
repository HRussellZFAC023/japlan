# Connectivity (eSIM + pocket Wi-Fi rental)

Transaction Amount: £43.24
Category: Tech
Comment: Ubigi 30-day eSIM + Ninja Wi-Fi rental for backup. City: Pre-trip Type: Data Status: To Book
Date: November 12, 2025
