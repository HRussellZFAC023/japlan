# W Osaka (Marvelous Suite, 2 nights)

Transaction Amount: £1,027.03
Category: Lodging
Comment: Use Suite Night Awards; request late checkout Nov 30. City: Osaka Type: Hotel Status: To Book
Date: November 28, 2025
