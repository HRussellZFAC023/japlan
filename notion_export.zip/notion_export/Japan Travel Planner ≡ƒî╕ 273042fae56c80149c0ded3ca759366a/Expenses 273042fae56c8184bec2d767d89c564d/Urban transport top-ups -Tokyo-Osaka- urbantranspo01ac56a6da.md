# Urban transport top-ups (Tokyo/Osaka)

Transaction Amount: £64.86
Category: Transport
Comment: Daily subway spend across Shibuya, Harajuku, Osaka loops. City: Tokyo/Osaka Type: Transit Status: Budget
Date: November 22, 2025
