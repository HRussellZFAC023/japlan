# Travel insurance (Comprehensive duo)

Transaction Amount: £151.35
Category: Admin
Comment: Covers winter sports/onsen, electronics, cancellations. City: Pre-trip Type: Insurance Status: Booked
Date: October 15, 2025
