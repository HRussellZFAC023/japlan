# Tea & sake carrier tube

Type: Shopping Support
Notes: Use for Uji purchases + Gekkeikan tasting souvenirs. Linked days: Days 4, 5, 16 Owner: Shared
Packed: No
Quantity: Protective tube for bottles & tea canisters
