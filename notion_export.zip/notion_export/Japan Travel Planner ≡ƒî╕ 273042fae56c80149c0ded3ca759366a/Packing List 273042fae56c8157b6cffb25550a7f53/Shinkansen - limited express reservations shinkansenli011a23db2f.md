# Shinkansen & limited express reservations

Type: Travel Essentials
Notes: Reserve Nozomi (Nov 22 & 24) + return seats for Nicole & Ken (Nov 28). Linked days: Days 9, 11, 15 Owner: You
Packed: No
Quantity: smartEX reservations + QR
