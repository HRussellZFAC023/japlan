# Outerwear duo (wool coat + packable down)

Type: Clothing
Notes: Down jacket compresses for Tokyo Disney nights; wool coat for birthday dinner. Linked days: Days 9-16 Owner: You
Packed: No
Quantity: 2 jackets
