# Flight e-tickets & insurance docs

Type: Travel Essentials
Notes: Store PDFs in Notion + Apple Wallet; print extra copy for Disney/USJ verification. Linked days: All travel days Owner: You
Packed: No
Quantity: Digital + 1 printed set
