# Laundry + steamer pouch

Type: Logistics
Notes: Use in Kyoto machiya & Tokyo apartment for mid-trip refresh. Linked days: Days 6, 10 Owner: Shared
Packed: No
Quantity: Travel steamer, detergent sheets, collapsible hamper
