# Connectivity pack

Type: Tech
Notes: Activate Ubigi eSIM 24h before departure; charge pocket Wi-Fi nightly. Linked days: Days 1-17 Owner: You
Packed: No
Quantity: eSIM QR + pocket Wi-Fi + SIM ejector
