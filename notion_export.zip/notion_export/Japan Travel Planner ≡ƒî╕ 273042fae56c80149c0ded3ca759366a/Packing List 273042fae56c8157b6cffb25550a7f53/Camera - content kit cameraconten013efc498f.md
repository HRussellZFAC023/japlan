# Camera & content kit

Type: Tech
Notes: Pack extra SD cards + ND filter for teamLab and Shibuya Sky. Linked days: Days 2-16 Owner: You
Packed: No
Quantity: Mirrorless body, 24mm + 50mm primes, DJI Pocket, mini tripod
