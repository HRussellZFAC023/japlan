# Sleepwear & loungewear

Type: Clothing
Notes: Mix-match for ryokan tatami nights and Tokyo sleepover aesthetic. Linked days: Days 6, 10, 11 Owner: Shared
Packed: No
Quantity: Lightweight set + cosy set each
