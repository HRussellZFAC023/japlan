# Aussie gift stash

Type: Gifts
Notes: Wrap individually for friends + Nana’s coworkers; include handwritten notes. Linked days: Days 9, 15 Owner: You
Packed: No
Quantity: Tim Tams, Indigenous art tea towels, mini boomerangs
