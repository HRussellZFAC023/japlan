# Power & charging hub

Type: Tech
Notes: Add spare adapter for Nicole & Ken during Osaka stay. Linked days: All days Owner: Shared
Packed: No
Quantity: 2 multi-USB bricks, 4 Type-A cables, 2 USB-C cables, 1 power board
