# Footwear rotation

Type: Clothing
Notes: Break-in sneakers beforehand; pack foldable slippers for ryokan + Airbnb. Linked days: Kyoto stay, Tokyo Airbnb, W Osaka Owner: Shared
Packed: No
Quantity: Waterproof sneakers + dress boots + indoor slippers
