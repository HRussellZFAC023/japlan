# Emergency snack pack

Type: Food
Notes: Great for long park days (USJ, Disney) and early train mornings. Linked days: Days 11, 14 Owner: You
Packed: No
Quantity: Protein bars, Berocca, electrolytes
