# Hair & styling toolkit

Type: Style
Notes: Essential for birthday glam + Harajuku looks. Linked days: Days 9 & 15 Owner: Shared
Packed: No
Quantity: Dual-voltage straightener, curl wand, styling clips
