# Onsen & sentō kit

Type: Wellness
Notes: Include modest swimwear for spa zones + waterproof phone pouch. Linked days: Days 5, 8, 13 Owner: Shared
Packed: No
Quantity: Mesh bag with towels, toiletries, tattoo covers
