# Wellness & med pouch

Type: Health
Notes: Include allergy meds for autumn pollen; keep duplicates in day bag. Linked days: All Owner: Shared
Packed: No
Quantity: Travel meds, motion sickness bands, pain relief patches
