# Multi-currency wallet (¥ cash + IC cards)

Type: Money & Access
Notes: Preload ICOCA with ¥5,000 each; stash emergency £ notes. Linked days: Daily transit Owner: Shared
Packed: No
Quantity: ¥120,000 + 2 IC cards
