# Passports + Visit Japan Web QR

Type: Travel Essentials
Notes: Keep in RFID pouch with Visit Japan Web screenshots for KIX arrival (Day 1). Linked days: Day 1 & Day 17 Owner: Shared
Packed: No
Quantity: 2
