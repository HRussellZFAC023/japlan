# Birthday outfits & accessories

Type: Style
Notes: Coordinate colour palette with Nicole & Ken; pack LED hair clips. Linked days: Day 15 Owner: Shared
Packed: No
Quantity: Neon glam look + backup smart casual
