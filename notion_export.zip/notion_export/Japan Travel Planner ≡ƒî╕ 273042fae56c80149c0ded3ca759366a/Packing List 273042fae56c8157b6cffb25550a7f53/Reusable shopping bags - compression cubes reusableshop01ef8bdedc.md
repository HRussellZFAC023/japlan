# Reusable shopping bags & compression cubes

Type: Logistics
Notes: Needed for Tokyo shopping haul + Kyoto leaf souvenirs. Linked days: Days 9, 16, 17 Owner: Shared
Packed: No
Quantity: 3 foldable totes + 4 packing cubes + vacuum bag
