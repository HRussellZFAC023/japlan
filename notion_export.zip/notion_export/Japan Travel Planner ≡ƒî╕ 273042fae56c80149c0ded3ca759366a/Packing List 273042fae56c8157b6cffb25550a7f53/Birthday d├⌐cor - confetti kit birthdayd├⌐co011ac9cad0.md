# Birthday décor & confetti kit

Type: Celebration
Notes: Pack in hard case; set up at W Osaka before dinner. Linked days: Day 15 Owner: You
Packed: No
Quantity: LED candles, tassel garland, sparkler candles
