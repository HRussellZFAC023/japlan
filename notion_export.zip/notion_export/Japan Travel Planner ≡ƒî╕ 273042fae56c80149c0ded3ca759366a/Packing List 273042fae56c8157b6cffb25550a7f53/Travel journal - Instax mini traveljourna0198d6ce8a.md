# Travel journal & Instax mini

Type: Memories
Notes: Collect stamps and Polaroids for Notion scrapbook import. Linked days: Daily reflection Owner: Shared
Packed: No
Quantity: Dot-grid notebook + Instax camera + 40 films
