# JR/Keihan rail pass kit

Type: Travel Essentials
Notes: Purchase Kansai Thru Pass at KIX; load Hirakata/Osaka itinerary inside. Linked days: Days 1-8, 12-17 Owner: Shared
Packed: No
Quantity: 1 Kansai-Thru Pass + 1 Keihan card sleeve
