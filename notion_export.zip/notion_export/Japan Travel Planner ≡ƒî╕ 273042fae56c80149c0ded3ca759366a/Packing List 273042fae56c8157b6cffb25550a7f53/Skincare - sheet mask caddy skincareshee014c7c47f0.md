# Skincare + sheet mask caddy

Type: Health
Notes: Share brightening masks with Nicole & Ken during Tokyo sleepover. Linked days: Days 10-15 Owner: Nana
Packed: No
Quantity: Routine minis + hydrating masks
