# Nintendo Switch party set

Type: Entertainment
Notes: Preload party playlist + update software before Nov 22 sleepover. Linked days: Day 10 Owner: You
Packed: No
Quantity: Switch OLED + Joy-Cons + Just Dance + Mario Kart
