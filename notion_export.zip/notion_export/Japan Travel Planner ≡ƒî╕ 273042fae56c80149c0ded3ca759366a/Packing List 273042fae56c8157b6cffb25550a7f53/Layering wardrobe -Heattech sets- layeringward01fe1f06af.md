# Layering wardrobe (Heattech sets)

Type: Clothing
Notes: Mix neutrals for Osaka city looks + Kyoto temple modesty. Linked days: All outdoor days Owner: Shared
Packed: No
Quantity: 4 base sets each
