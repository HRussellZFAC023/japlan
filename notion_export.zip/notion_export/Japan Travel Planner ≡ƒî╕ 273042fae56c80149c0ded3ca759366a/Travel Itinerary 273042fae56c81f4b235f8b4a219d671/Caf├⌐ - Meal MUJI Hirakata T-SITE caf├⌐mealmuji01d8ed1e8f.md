# Café & Meal MUJI Hirakata T-SITE

Group: Hirakata
Day: Day 5
Type: Food
Notes: 12:15-13:00 — Healthy tray lunch of seasonal deli picks, miso soup, and yuzu soda to keep energy up mid-workday. Order 4-item plate (~¥1,100). Grab take-home snacks for train rides later in the week. Booking: No reservations; self-service ordering kiosk. With You + Nana Approx spend £11.89 Check MUJI travel section for packing cubes before Tokyo.
Visited: No

[Address: 12-２ Okahigashichō, Hirakata, Osaka 573-0032, Japan](https://maps.google.com/?cid=17127482803001824153)
Rating: 3.9 (6056 reviews)
Phone: +81 72-844-9000
Website: https://store.tsite.jp/hirakata/
Coordinates: 34.8158936, 135.6497036

![café___meal_muji_hirakata_t_site.jpg](Caf%C3%A9%20-%20Meal%20MUJI%20Hirakata%20T-SITE%20caf%C3%A9mealmuji01d8ed1e8f/caf%C3%A9___meal_muji_hirakata_t_site.jpg)
