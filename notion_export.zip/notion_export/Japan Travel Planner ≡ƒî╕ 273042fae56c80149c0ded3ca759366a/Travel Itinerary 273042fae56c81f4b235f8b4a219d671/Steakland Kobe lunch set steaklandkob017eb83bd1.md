# Steakland Kobe lunch set

Group: Kobe
Day: Day 13
Type: Food
Notes: 12:30-14:00 — Classic teppan Kobe beef lunch with live chef performance—best value wagyu feast. 10-minute walk from Sannomiya. Lunch set ¥3,480 pp includes soup, salad, rice, dessert. Booking: Call morning-of to secure counter seats; note medium-rare preference. With You + Nana Approx spend £43.24 Add garlic chips and sparkling sake pairing.
Visited: No

[Address: Japan, 〒650-1112 Hyogo, Kobe, Chuo Ward, Kitanagasadōri, 1-chōme−9−１７ 三宮興業ビル ６階](https://maps.google.com/?cid=4268193972152431843)
Rating: 4 (8712 reviews)
Phone: +81 78-332-2900
Website: https://steakland-kobe.jp/
Coordinates: 34.6930016, 135.1917353

![steakland_kobe_lunch_set.jpg](Steakland%20Kobe%20lunch%20set%20steaklandkob017eb83bd1/steakland_kobe_lunch_set.jpg)
