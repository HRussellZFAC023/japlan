# Nakatanidou mochi theatrics

Group: Nara
Day: Day 4
Type: Food
Notes: 11:40-12:10 — Catch the famous high-speed mochi pounding show and snack on warm yomogi mochi dusted in kinako. 5-minute walk from Kintetsu Nara Station. Shows roughly every 30 minutes—arrive just before noon. Booking: None; cash only (¥130 per mochi). With You + Nana Approx spend £2.70 Record slow-mo video for Instagram reel.
Visited: No

[Address: 29 Hashimotochō, Nara, 630-8217, Japan](https://maps.google.com/?cid=14561917136571056776)
Rating: 4.3 (5426 reviews)
Phone: +81 742-23-0141
Website: http://www.nakatanidou.jp/
Coordinates: 34.681943, 135.8288995

![nakatanidou_mochi_theatrics.jpg](Nakatanidou%20mochi%20theatrics%20nakatanidoum01c312dcd0/nakatanidou_mochi_theatrics.jpg)
