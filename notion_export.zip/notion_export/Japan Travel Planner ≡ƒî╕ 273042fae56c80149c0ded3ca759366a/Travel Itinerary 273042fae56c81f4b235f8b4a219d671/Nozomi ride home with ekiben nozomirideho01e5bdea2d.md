# Nozomi ride home with ekiben

Group: Tokyo → Osaka
Day: Day 11
Type: Transport
Notes: 19:40-22:30 — Board Nozomi 273 back to Shin-Osaka with Tokyo Station bento feast and birthday countdown playlist planning. Depart Tokyo Station 19:40 (arrive 22:13). Reserve seats in car 13 for luggage space. Booking: Use smartEX app to book seats; pick up at ticket machine. With You + Nana Approx spend £162.16 Wave goodbye to Nicole & Ken as they head back to Chiba.
Visited: No

[Address: 1 Chome-9 Marunouchi, Chiyoda City, Tokyo 100-0005, Japan](https://maps.google.com/?cid=11114180190203192)
Rating: 4.3 (14010 reviews)
Website: https://www.tokyoinfo.com/
Coordinates: 35.6812996, 139.7670658

![nozomi_ride_home_with_ekiben.jpg](Nozomi%20ride%20home%20with%20ekiben%20nozomirideho01e5bdea2d/nozomi_ride_home_with_ekiben.jpg)
