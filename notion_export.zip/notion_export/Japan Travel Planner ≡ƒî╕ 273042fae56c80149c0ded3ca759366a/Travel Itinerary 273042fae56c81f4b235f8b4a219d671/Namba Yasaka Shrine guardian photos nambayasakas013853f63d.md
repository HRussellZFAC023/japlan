# Namba Yasaka Shrine guardian photos

Group: Osaka
Day: Day 2
Type: Culture
Notes: 15:00-15:40 — Snap surreal shots in front of the iconic lion-head stage and leave ema wishes for the journey. 10-minute stroll from Kuromon via backstreets; best lighting mid-afternoon. Booking: None. With You + Nana Approx spend £2.70 Collect goshuin stamp for the travel shrine book.
Visited: No

[Address: 2-chōme-9-19 Motomachi, Naniwa Ward, Osaka, 556-0016, Japan](https://maps.google.com/?cid=9278387310004857503)
Rating: 4.4 (12235 reviews)
Phone: +81 6-6641-1149
Website: https://nambayasaka.jp/
Coordinates: 34.66155920000001, 135.4967039

![namba_yasaka_shrine_guardian_photos.jpg](Namba%20Yasaka%20Shrine%20guardian%20photos%20nambayasakas013853f63d/namba_yasaka_shrine_guardian_photos.jpg)
