# Gekkeikan Okura Sake Museum tasting flight

Group: Kyoto
Day: Day 3
Type: Food & Drink
Notes: 18:15-19:30 — Sample aged sake in the heart of Fushimi, blending history with guided tasting notes perfect for gifting. Walk 12 minutes from Inari to Chushojima area (or quick Keihan ride). Last tasting entry 19:00. Booking: Reserve premium tasting course (¥1,000) for English guide availability. With You + Nana Approx spend £10.81 Ship bottle set to Nana’s apartment to avoid luggage weight.
Visited: No

[Address: 247 Minamihamachō, Fushimi Ward, Kyoto, 612-8660, Japan](https://maps.google.com/?cid=9137465178982848979)
Rating: 4.2 (4341 reviews)
Phone: +81 75-623-2056
Website: https://www.gekkeikan.co.jp/enjoy/museum/
Coordinates: 34.929136, 135.76161

![gekkeikan_okura_sake_museum_tasting_flight.jpg](Gekkeikan%20Okura%20Sake%20Museum%20tasting%20flight%20gekkeikanoku01df55ff25/gekkeikan_okura_sake_museum_tasting_flight.jpg)
