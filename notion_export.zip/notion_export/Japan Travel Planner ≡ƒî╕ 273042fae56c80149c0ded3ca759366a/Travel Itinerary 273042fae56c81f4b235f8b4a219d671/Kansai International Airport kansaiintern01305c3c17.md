# Kansai International Airport

Group: Osaka
Day: Day 1
Type: Arrival
Notes: 10:30-12:00 — Touch down, breeze through Smart Immigration, and pick up ICOCA & Haruka passes for the fortnight of Kansai adventures. Follow signage to JR Ticket Office (Level 2) for the ICOCA & HARUKA bundle; allow 45 minutes for immigration & luggage. Booking: Pre-fill Visit Japan Web QR codes; seat reservations optional on Haruka Express (green car recommended with luggage). With You + Nana (evening meet-up) Flight arrival planned for 10:30 JST — adjust if airline changes schedule.
Visited: No

[Address: Terminal 1, Osaka, Japan](https://maps.google.com/?cid=12104414214768042484)
Coordinates: 34.4348282, 135.2446195

![kansai_international_airport.jpg](Kansai%20International%20Airport%20kansaiintern01305c3c17/kansai_international_airport.jpg)
