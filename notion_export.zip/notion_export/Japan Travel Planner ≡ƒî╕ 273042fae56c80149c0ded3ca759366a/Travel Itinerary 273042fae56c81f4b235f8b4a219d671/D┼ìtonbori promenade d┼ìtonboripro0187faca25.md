# Dōtonbori promenade

Group: Osaka
Day: Day 1
Type: Neighbourhood Stroll
Notes: 17:00-18:00 — Ease into the neon with a golden-hour stroll beneath the Glico sign, sampling street snacks and capturing the first couple snaps. Keihan line to Yodoyabashi → Midosuji subway to Namba (30 min). Hit Don Quijote for Suica/ICOCA top-ups and trip mascot souvenirs. Booking: None; aim for 17:00 for dusk reflections. With You + Nana Approx spend £10.81 Pick up matching gachapon keychains as kick-off ritual.
Visited: No

[Address: Dotonbori, Chuo Ward, Osaka, 542-0071, Japan](https://maps.google.com/?cid=16446419638008461065)
Coordinates: 34.6686471, 135.5030983

![dōtonbori_promenade.jpg](D%C5%8Dtonbori%20promenade%20d%C5%8Dtonboripro0187faca25/d%C5%8Dtonbori_promenade.jpg)
