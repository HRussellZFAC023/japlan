# Kushikatsu Tanaka Hirakata

Group: Hirakata
Day: Day 5
Type: Food
Notes: 20:15-21:30 — Late-night skewers, DIY sauce, and highball towers steps from Nana’s station—casual, comforting, delicious. Book corner booth; share kushi-katsu set + cheese fondue skewers. Average spend ¥3,000 for two with drinks. Booking: Use Tabelog to secure 20:15 slot (English-friendly). With You + Nana Approx spend £32.43 Ask staff about November limited-time skewers for birthday week inspiration.
Visited: No

[Address: 19-1 Okahigashichō, Hirakata, Osaka 573-0032, Japan](https://maps.google.com/?cid=12975794440701677436)
Rating: 4.5 (1335 reviews)
Phone: +81 72-896-9450
Website: https://kushi-tanaka.com/restaurant/detail/hirakata-mall?utm_source=google&utm_medium=maps&utm_campaign=gmb
Coordinates: 34.8170855, 135.6504186

![kushikatsu_tanaka_hirakata.jpg](Kushikatsu%20Tanaka%20Hirakata%20kushikatsuta0182e60131/kushikatsu_tanaka_hirakata.jpg)
