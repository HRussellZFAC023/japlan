# Kiyomizu-dera sunrise blessings

Group: Kyoto
Day: Day 7
Type: Culture
Notes: 06:00-07:15 — Beat the crowds to watch sunlight spill over Kyoto from the wooden stage while bells echo. Stay near temple overnight; gates open 06:00. Carry ¥400 entry fee in coins. Booking: None. With You + Nana Approx spend £4.32 Collect omikuji for upcoming Tokyo luck.
Visited: No

[Address: 1-chōme-294 Kiyomizu, Higashiyama Ward, Kyoto, 605-0862, Japan](https://maps.google.com/?cid=7111013964196361402)
Rating: 4.5 (62528 reviews)
Phone: +81 75-551-1234
Website: https://www.kiyomizudera.or.jp/
Coordinates: 34.9946662, 135.784661

![kiyomizu_dera_sunrise_blessings.jpg](Kiyomizu-dera%20sunrise%20blessings%20kiyomizudera01d0600949/kiyomizu_dera_sunrise_blessings.jpg)
