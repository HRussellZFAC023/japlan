# Tsuen Tea master tasting

Group: Uji
Day: Day 4
Type: Food & Drink
Notes: 15:00-16:00 — Sip hand-whisked matcha and gyokuro flight at the world’s oldest tea shop, learning whisk techniques from tea masters. Located beside Uji Bridge; reserve tea experience (¥2,500 pp). Allow extra time to browse teaware. Booking: Book tasting counter 2 weeks ahead; request English notes. With You + Nana Approx spend £27.03 Buy travel-friendly canisters for Tokyo friend gifts.
Visited: No

[Address: Higashiuchi-1 Uji, Kyoto 611-0021, Japan](https://maps.google.com/?cid=2102438674156082753)
Rating: 4.3 (1052 reviews)
Phone: +81 774-21-2243
Website: http://www.tsuentea.com/
Coordinates: 34.89329, 135.8072759

![tsuen_tea_master_tasting.jpg](Tsuen%20Tea%20master%20tasting%20tsuenteamast01cdfc613f/tsuen_tea_master_tasting.jpg)
