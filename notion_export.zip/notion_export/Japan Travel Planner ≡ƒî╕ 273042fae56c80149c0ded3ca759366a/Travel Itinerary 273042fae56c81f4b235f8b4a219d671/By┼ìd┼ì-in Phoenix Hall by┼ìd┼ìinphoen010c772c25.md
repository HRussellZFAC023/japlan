# Byōdō-in Phoenix Hall

Group: Uji
Day: Day 4
Type: Culture
Notes: 13:30-15:00 — Admire the iconic Phoenix Hall mirrored in the reflecting pond, stepping inside for the gold-leaf interior tour. JR Nara Line to Uji (30 min). Entry ¥700 + ¥300 museum; interior tour timed—collect tickets upon arrival. Booking: Optional: pre-book English audio guide. With You + Nana Approx spend £10.81 Pick up commemorative ¥10 coin reproduction from gift shop.
Visited: No

[Address: Renge-116 Uji, Kyoto 611-0021, Japan](https://maps.google.com/?cid=6954706348575164324)
Rating: 4.5 (20471 reviews)
Phone: +81 774-21-2861
Website: https://www.byodoin.or.jp/
Coordinates: 34.8892908, 135.8076783

![byōdō_in_phoenix_hall.jpg](By%C5%8Dd%C5%8D-in%20Phoenix%20Hall%20by%C5%8Dd%C5%8Dinphoen010c772c25/by%C5%8Dd%C5%8D_in_phoenix_hall.jpg)
