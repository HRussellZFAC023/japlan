# Tōdai-ji Daibutsuden

Group: Nara
Day: Day 4
Type: Culture
Notes: 09:00-10:30 — Stand beneath the 15-meter bronze Buddha and enjoy the morning chanting echoing through the ancient hall. Kintetsu rapid to Nara (55 min). Buy combo ticket (¥1,000) covering museum if interested. Booking: Arrive at opening to avoid school groups. With You + Nana Approx spend £10.81 Carry deer senbei in tote pocket for surprise cameos.
Visited: No

[Address: 406-1 Zōshichō, Nara, 630-8587, Japan](https://maps.google.com/?cid=17911005107283377295)
Rating: 4.6 (28508 reviews)
Phone: +81 742-22-5511
Website: https://www.todaiji.or.jp/
Coordinates: 34.6889851, 135.8398158

![tōdai_ji_daibutsuden.jpg](T%C5%8Ddai-ji%20Daibutsuden%20t%C5%8Ddaijidaibu0171d54360/t%C5%8Ddai_ji_daibutsuden.jpg)
