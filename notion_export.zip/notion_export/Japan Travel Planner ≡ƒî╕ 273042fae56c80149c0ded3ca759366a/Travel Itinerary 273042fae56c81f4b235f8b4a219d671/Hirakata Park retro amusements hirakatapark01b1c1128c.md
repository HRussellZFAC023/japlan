# Hirakata Park retro amusements

Group: Hirakata
Day: Day 8
Type: Experience
Notes: 15:30-17:30 — Celebrate end of workweek with gentle coasters, Ferris wheel selfies, and warm crepes in the vintage amusement park. Discount twilight tickets from 15:00 (~¥1,500). Keep ride choices mild ahead of shinkansen weekend. Booking: Check seasonal illumination schedule; pre-book if limited. With You + Nana Approx spend £16.22 Ride Sky Walker for panoramic sunset over Osaka riverways.
Visited: No

[Address: 1-1 Hirakatakōenchō, Hirakata, Osaka 573-0054, Japan](https://maps.google.com/?cid=6647979896880488689)
Rating: 4.3 (8973 reviews)
Website: http://www.hirakatapark.co.jp/
Coordinates: 34.8059896, 135.6392002

![hirakata_park_retro_amusements.jpg](Hirakata%20Park%20retro%20amusements%20hirakatapark01b1c1128c/hirakata_park_retro_amusements.jpg)
