# Tonbori River Cruise

Group: Osaka
Day: Day 1
Type: Experience
Notes: 18:15-18:45 — Sail past Osaka’s LED canyon; perfect for first-night wow shots and a quick rest for jet-lagged feet. Board at Tazaemon-bashi Dock. Arrive 15 minutes early to swap QR voucher for tickets. Booking: Reserve online (¥1,200 pp); choose front-row seats for unobstructed photos. With You + Nana Approx spend £12.97 Pack light jacket — November breezes over the canal can be crisp.
Visited: No

[Address: 7-13 Souemonchō, Chuo Ward, Osaka, 542-0084, Japan](https://maps.google.com/?cid=11944000788392540382)
Rating: 4.4 (1814 reviews)
Phone: +81 50-1807-4118
Website: http://www.ipponmatsu.co.jp/cruise/tombori.html
Coordinates: 34.6691432, 135.502709

![tonbori_river_cruise.jpg](Tonbori%20River%20Cruise%20tonboririver0147349808/tonbori_river_cruise.jpg)
