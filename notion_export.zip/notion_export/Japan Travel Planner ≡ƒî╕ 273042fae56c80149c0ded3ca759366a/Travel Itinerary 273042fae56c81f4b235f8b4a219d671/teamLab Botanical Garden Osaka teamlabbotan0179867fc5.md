# teamLab Botanical Garden Osaka

Group: Osaka
Day: Day 2
Type: Immersive Art
Notes: 18:00-20:00 — Nighttime digital art woven through Nagai Botanical Garden—glowing eggs, mirrored ponds, and luminous bamboo groves. Subway Midosuji Line to Nagai (20 min from Shinsaibashi). Allow 90 minutes to wander loops; bring lightweight tripod alternative. Booking: Secure 18:00 entry slot (¥1,800 pp) through teamLab website two months ahead. With You + Nana Approx spend £19.46 Check weather—open-air event; reschedule option needed if heavy rain.
Visited: No

[Address: 1-23 Nagaikōen, Higashisumiyoshi Ward, Osaka, 546-0034, Japan](https://maps.google.com/?cid=4949594704093356283)
Rating: 3.9 (2109 reviews)
Phone: +81 6-6699-5120
Website: https://www.teamlab.art/jp/e/botanicalgarden/
Coordinates: 34.6110004, 135.5204213

![teamlab_botanical_garden_osaka.jpg](teamLab%20Botanical%20Garden%20Osaka%20teamlabbotan0179867fc5/teamlab_botanical_garden_osaka.jpg)
