# Afuri Harajuku yuzu ramen lunch

Group: Tokyo
Day: Day 9
Type: Food
Notes: 12:30-13:30 — Freshen up with light yuzu shio ramen and vegan seasonal bowls before diving into Takeshita chaos. Order via vending machine; share karaage side. Seating limited—arrive before peak rush. Booking: No reservations; have Suica ready for quick payment. With You + Nana + Nicole + Ken Approx spend £27.03 Nicole loves spicy—grab the tsukemen option for her.
Visited: No

[Address: Japan, 〒151-0051 Tokyo, Shibuya, Sendagaya, 3-chōme−63−１ グランデフォレスタ原宿 1F](https://maps.google.com/?cid=14658399961265590294)
Rating: 4.4 (4205 reviews)
Website: https://afuri.com/
Coordinates: 35.6730053, 139.7038019

![afuri_harajuku_yuzu_ramen_lunch.jpg](Afuri%20Harajuku%20yuzu%20ramen%20lunch%20afuriharajuk01e4a2750a/afuri_harajuku_yuzu_ramen_lunch.jpg)
