# sequence MIYASHITA PARK check-in

Group: Tokyo
Day: Day 9
Type: Lodging
Notes: 11:30-12:00 — Drop bags at the design hotel hugging Miyashita Park—perfect base between Shibuya and Harajuku. Nozomi 16 from Shin-Osaka (08:00-10:30). Early baggage drop available; request high-floor park view. Booking: Reserve 1 night (Nov 22) double room; ask for late checkout 12:00. With You + Nana Approx spend £140.54 Use hotel lockers for Nicole & Ken’s bags if they arrive early.
Visited: No

[Address: MIYASHITA PARK North, 6-chōme-20-10 Jingūmae, Shibuya, Tokyo 150-0001, Japan](https://maps.google.com/?cid=9510849312829855018)
Rating: 3.9 (809 reviews)
Phone: +81 3-5468-6131
Website: https://www.sequencehotels.com/miyashita-park/?utm_source=googlebusinessprofile&utm_medium=google&utm_campaign=maps
Coordinates: 35.6622585, 139.7019016

![sequence_miyashita_park_check_in.jpg](sequence%20MIYASHITA%20PARK%20check-in%20sequencemiya014f7c07af/sequence_miyashita_park_check_in.jpg)
