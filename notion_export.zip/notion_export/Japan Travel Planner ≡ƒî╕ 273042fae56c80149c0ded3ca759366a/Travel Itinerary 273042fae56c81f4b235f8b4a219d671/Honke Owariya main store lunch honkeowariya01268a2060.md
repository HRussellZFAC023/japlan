# Honke Owariya main store lunch

Group: Kyoto
Day: Day 6
Type: Food
Notes: 13:00-14:00 — Taste Kyoto’s oldest soba paired with tempura and seasonal sweets in a 550-year-old merchant house. 10-minute walk from Camellia. Try Hourai soba set (~¥1,600). Booking: Call to reserve upstairs tatami seating; mention dietary notes. With You + Nana Approx spend £18.92 Purchase soba cookies for tea-time gifts.
Visited: No

[Address: 322 Niōmontsukinukechō, Nakagyo Ward, Kyoto, 604-0841, Japan](https://maps.google.com/?cid=16359369336265180348)
Rating: 4.3 (2271 reviews)
Phone: +81 75-231-3446
Website: http://honke-owariya.co.jp/
Coordinates: 35.0127635, 135.7601488

![honke_owariya_main_store_lunch.jpg](Honke%20Owariya%20main%20store%20lunch%20honkeowariya01268a2060/honke_owariya_main_store_lunch.jpg)
