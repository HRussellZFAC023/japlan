# teamLab Planets TOKYO DMM

Group: Tokyo
Day: Day 10
Type: Immersive Art
Notes: 09:00-11:00 — Barefoot, multi-sensory art spaces with mirrored water rooms—perfect for collaborative photos. Yurikamome to Shin-Toyosu. Bring small towel for water installations. Booking: Book 09:00 slot (¥3,800 pp). Add photo plan for digital downloads. With You + Nana + Nicole + Ken Approx spend £82.16 Coordinate matching monochrome outfits for reflective shots.
Visited: No

[Address: 6-chōme-1-16 Toyosu, Koto City, Tokyo 135-0061, Japan](https://maps.google.com/?cid=7918542870314997282)
Rating: 4.5 (44317 reviews)
Website: https://www.teamlab.art/jp/e/planets/
Coordinates: 35.6491207, 139.7897739

![teamlab_planets_tokyo_dmm.jpg](teamLab%20Planets%20TOKYO%20DMM%20teamlabplane01bbf35e97/teamlab_planets_tokyo_dmm.jpg)
