# Torisei Hirakata sake dinner

Group: Hirakata
Day: Day 8
Type: Food
Notes: 18:30-20:00 — Charcoal yakitori matched with Fushimi sake flights before packing for Tokyo. Book counter seats; budget ¥3,500 for shared platters. Order seasonal hotpot special. Booking: Reserve by phone; mention celebratory trip for omakase extras. With You + Nana Approx spend £37.84 Gift staff sake from Gekkeikan visit.
Visited: No

[Address: 19-1 Okahigashichō, Hirakata, Osaka 573-0032, Japan](https://maps.google.com/?cid=2157355754970212496)
Rating: 3.2 (51 reviews)
Phone: +81 72-807-8884
Website: https://akr2875411535.owst.jp/
Coordinates: 34.8175934, 135.6504183

![torisei_hirakata_sake_dinner.jpg](Torisei%20Hirakata%20sake%20dinner%20toriseihirak0189f71793/torisei_hirakata_sake_dinner.jpg)
