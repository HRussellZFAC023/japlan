# Kyomachiya Ryokan Sakura Urushitei

Group: Kyoto
Day: Day 6
Type: Lodging
Notes: 15:00 check-in — Check into an artisan machiya with hinoki baths, yukata sets, and traditional breakfast service. Walk 12 minutes from Karasuma Station. Request luggage forwarding from Osaka using Yamato (~¥1,500). Booking: Book courtyard suite for 19 Nov; include breakfast and kaiseki dinner upgrade. With You + Nana Approx spend £216.22 Arrange tatami tea-time photos before dinner.
Visited: No

[Address: 425 Kichimonjichō, Shimogyo Ward, Kyoto, 600-8069, Japan](https://maps.google.com/?cid=3664127484669648848)
Rating: 4.5 (630 reviews)
Phone: +81 75-343-0003
Website: https://www.kyoto-ryokan-sakura.com/urushi/home_jp/
Coordinates: 35.0000557, 135.7643635

![kyomachiya_ryokan_sakura_urushitei.jpg](Kyomachiya%20Ryokan%20Sakura%20Urushitei%20kyomachiyary01f245a5d9/kyomachiya_ryokan_sakura_urushitei.jpg)
