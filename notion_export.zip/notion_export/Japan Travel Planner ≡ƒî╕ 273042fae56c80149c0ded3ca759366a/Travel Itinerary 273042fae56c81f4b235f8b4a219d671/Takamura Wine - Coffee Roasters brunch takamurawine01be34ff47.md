# Takamura Wine & Coffee Roasters brunch

Group: Osaka
Day: Day 17
Type: Food
Notes: 10:00-11:30 — Celebrate the journey with artisanal coffee cupping and light brunch in a lofted roastery. Taxi from W Osaka (10 min). Reserve tasting flight with seasonal beans. Booking: Book cupping session for two; pick up beans for home brewing. With You + Nana + Nicole + Ken Approx spend £43.24 Purchase natural wine for holiday gifting (ship via EMS).
Visited: No

[Address: 2-chōme-2-18 Edobori, Nishi Ward, Osaka, 550-0002, Japan](https://maps.google.com/?cid=18436798584987103295)
Rating: 4.4 (1678 reviews)
Phone: +81 6-6443-3519
Website: http://takamuranet.com/
Coordinates: 34.687283, 135.491105

![takamura_wine___coffee_roasters_brunch.jpg](Takamura%20Wine%20-%20Coffee%20Roasters%20brunch%20takamurawine01be34ff47/takamura_wine___coffee_roasters_brunch.jpg)
