# Tokyo DisneySea adventure

Group: Tokyo
Day: Day 11
Type: Theme Park
Notes: 08:00-19:00 — Soar on Soaring, dive into Journey to the Center, and catch the evening Harbor of Dreams show with Christmas overlays. Resort line from Maihama Station; use Premier Access for Soaring + Journey to shorten queues. Booking: Buy 1-day passports (¥10,900 pp) + 2 Premier Access per headline attraction. With You + Nana + Nicole + Ken Approx spend £235.68 Coordinate group outfits (earth-tone Disney-bounding).
Visited: No

[Address: 1-13 Maihama, Urayasu, Chiba 279-8511, Japan](https://maps.google.com/?cid=4703760703938833701)
Rating: 4.6 (98977 reviews)
Phone: +81 45-330-5211
Website: https://www.tokyodisneyresort.jp/tds/
Coordinates: 35.6267108, 139.8850779

![tokyo_disneysea_adventure.jpg](Tokyo%20DisneySea%20adventure%20tokyodisneys0113328ce3/tokyo_disneysea_adventure.jpg)
