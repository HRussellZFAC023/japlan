# Karaoke Kan Shinsaibashi takeover

Group: Osaka
Day: Day 15
Type: Nightlife
Notes: 21:00-23:30 — Private neon room with unlimited drinks, photobooth props, and birthday slideshow during choruses. Reserve VIP room; bring HDMI cable for slideshow. Order sparkling sake tower. Booking: Book 3-hour premium plan with open bar via Jalan Net. With You + Nana + Nicole + Ken + Osaka friends (optional) Approx spend £129.73 Surprise Ken with co-birthday montage at 22:00.
Visited: No

[Address: Japan, 〒542-0076 Osaka, Chuo Ward, Namba, 1-chōme−5−１６ 大阪B&Vビル](https://maps.google.com/?cid=2046130830251139311)
Rating: 3.6 (204 reviews)
Phone: +81 6-4708-1061
Website: https://karaokekan.jp/shop/detail/182
Coordinates: 34.6678073, 135.5014099

![karaoke_kan_shinsaibashi_takeover.jpg](Karaoke%20Kan%20Shinsaibashi%20takeover%20karaokekansh0136f5eb6d/karaoke_kan_shinsaibashi_takeover.jpg)
