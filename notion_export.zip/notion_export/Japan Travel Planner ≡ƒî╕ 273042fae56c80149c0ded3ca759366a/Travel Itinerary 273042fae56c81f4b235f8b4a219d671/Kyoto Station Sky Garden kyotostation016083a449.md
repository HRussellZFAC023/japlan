# Kyoto Station Sky Garden

Group: Kyoto
Day: Day 7
Type: Viewpoint
Notes: 14:00-14:45 — Catch futuristic architecture and secret rooftop garden before boarding the train south. Take escalators to 11F; free entry. Grab Kyoto-style ekiben for train. Booking: None. With You + Nana Film time-lapse of escalator axis for trip vlog.
Visited: No

[Address: Higashishiokoji Kamadonocho, Shimogyo Ward, Kyoto, 600-8216, Japan](https://maps.google.com/?cid=13121875705491233800)
Rating: 4.3 (8358 reviews)
Website: https://www.jr-odekake.net/eki/top.php?id=0610116
Coordinates: 34.985849, 135.7587667

![kyoto_station_sky_garden.jpg](Kyoto%20Station%20Sky%20Garden%20kyotostation016083a449/kyoto_station_sky_garden.jpg)
