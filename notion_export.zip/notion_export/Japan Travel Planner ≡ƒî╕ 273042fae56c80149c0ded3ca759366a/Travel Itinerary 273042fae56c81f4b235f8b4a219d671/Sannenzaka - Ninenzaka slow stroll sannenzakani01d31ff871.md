# Sannenzaka & Ninenzaka slow stroll

Group: Kyoto
Day: Day 7
Type: Shopping
Notes: 07:15-08:00 — Browse early-opening ceramics and craft shops before day-trippers flood the slopes. Start at Kiyomizu exit; stop at Starbucks Ninenzaka for Kyoto-only merch at 08:00. Booking: None; pre-list must-visit boutiques. With You + Nana Approx spend £21.62 Buy engraved chopsticks for birthday dinner table settings.
Visited: No

[Address: 2-chōme-211 Kiyomizu, Higashiyama Ward, Kyoto, 605-0862, Japan](https://maps.google.com/?cid=11767990651930696711)
Rating: 4.4 (15276 reviews)
Coordinates: 34.9966644, 135.781008

![sannenzaka___ninenzaka_slow_stroll.png](Sannenzaka%20-%20Ninenzaka%20slow%20stroll%20sannenzakani01d31ff871/sannenzaka___ninenzaka_slow_stroll.png)
