# Okutan Nanzenji yudofu lunch

Group: Kyoto
Day: Day 16
Type: Food
Notes: 12:30-13:45 — Traditional tofu kaiseki in a tatami room overlooking a moss garden—warming and serene. Reserve tatami room; lunch course ¥3,800 pp. Remove shoes at entry. Booking: Call ahead; mention vegetarian-friendly preferences. With You + Nana + Nicole + Ken Approx spend £86.49 Pre-order sansho pepper tofu for take-home treat.
Visited: No

[Address: 86-30 Nanzenji Fukuchichō, Sakyo Ward, Kyoto, 606-8435, Japan](https://maps.google.com/?cid=737529368844235860)
Rating: 4.1 (285 reviews)
Phone: +81 75-771-8709
Coordinates: 35.0122585, 135.7930363

![okutan_nanzenji_yudofu_lunch.jpg](Okutan%20Nanzenji%20yudofu%20lunch%20okutannanzen01083142a5/okutan_nanzenji_yudofu_lunch.jpg)
