# MIMARU Tokyo Shinjuku WEST pajama party

Group: Tokyo
Day: Day 10
Type: Lodging
Notes: 15:00 check-in — Apartment-style suite with tatami bunk beds, kitchen for snacks, and board games for a nostalgic sleepover. Taxi from Nihonbashi (~25 min). Request Pokémon-themed room if available. Booking: Book 2-bedroom suite for Nov 23; add breakfast basket. With You + Nana + Nicole + Ken Approx spend £194.59 Set up projector for Mario Kart tournament.
Visited: No

[Address: 3-chōme-3-11 Nishishinjuku, Shinjuku City, Tokyo 160-0023, Japan](https://maps.google.com/?cid=15607418906888136225)
Rating: 4.7 (441 reviews)
Phone: +81 3-6258-1512
Website: https://mimaruhotels.com/ja/hotel/shinjuku-west/?utm_source=google&utm_medium=map&utm_campaign=shinjuku
Coordinates: 35.6860556, 139.6929722

![mimaru_tokyo_shinjuku_west_pajama_party.jpg](MIMARU%20Tokyo%20Shinjuku%20WEST%20pajama%20party%20mimarutokyos0198b702b7/mimaru_tokyo_shinjuku_west_pajama_party.jpg)
