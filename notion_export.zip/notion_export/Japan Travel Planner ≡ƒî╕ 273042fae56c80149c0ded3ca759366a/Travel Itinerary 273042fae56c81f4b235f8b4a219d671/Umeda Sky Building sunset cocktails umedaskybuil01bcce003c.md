# Umeda Sky Building sunset cocktails

Group: Osaka
Day: Day 7
Type: Viewpoint
Notes: 17:30-19:00 — Toast with sky-high cocktails as Osaka transitions from gold to neon at the Floating Garden Observatory. JR Loop to Osaka Station; elevator + escalator to 39F. Entry ¥1,500 pp; bar menu extra. Booking: Pre-book sunset slot; bring smartphone gimbal for skyline shots. With You + Nana Approx spend £32.43 Scout vantage points for birthday sparkler photos.
Visited: No

[Address: 1-chōme-1-88 Ōyodonaka, Kita Ward, Osaka, 531-6023, Japan](https://maps.google.com/?cid=6323866581023509245)
Rating: 4.4 (36890 reviews)
Website: https://www.skybldg.co.jp/en/
Coordinates: 34.7052872, 135.4896527

![umeda_sky_building_sunset_cocktails.jpg](Umeda%20Sky%20Building%20sunset%20cocktails%20umedaskybuil01bcce003c/umeda_sky_building_sunset_cocktails.jpg)
