# Arima Onsen Taiko-no-yu

Group: Arima
Day: Day 13
Type: Wellness
Notes: 15:00-18:00 — Soak in gold and silver springs, explore cave baths, and book a private relaxation room. Hankyu Bus from Sannomiya (35 min). Entry ¥2,750; rent yukata + towel set. Booking: Reserve private tatami lounge for two hours (+¥3,000). With You + Nana Approx spend £43.24 Hydrate with locally bottled carbonated Arima water.
Visited: No

[Address: 池の尻-292-2 Arimachō, Kita Ward, Kobe, Hyogo 651-1401, Japan](https://maps.google.com/?cid=16499097178660564879)
Rating: 3.7 (2448 reviews)
Phone: +81 78-904-2291
Website: http://www.taikounoyu.com/
Coordinates: 34.7979027, 135.2512053

![arima_onsen_taiko_no_yu.jpg](Arima%20Onsen%20Taiko-no-yu%20arimaonsenta019c626cbc/arima_onsen_taiko_no_yu.jpg)
