# Brooklyn Roasting Company Kitahama

Group: Osaka
Day: Day 2
Type: Coffee
Notes: 09:00-10:00 — Fuel up riverside with Kyoto-sourced beans and plan the day over almond croissants in the airy loft. Keihan express to Kitahama (20 min). Grab window seats upstairs for canal views. Booking: None; arrive before 09:30 to beat the weekend crowd. With You + Nana Approx spend £9.73 Bring reusable tumbler for iced seasonal blends.
Visited: No

[Address: Japan, 〒541-0041 Osaka, Chuo Ward, Kitahama, 1-chōme−1−９ ハウザー 北浜ビル 1F](https://maps.google.com/?cid=3143396422888168986)
Rating: 4.4 (1747 reviews)
Phone: +81 6-6125-5740
Website: http://brooklynroasting.jp/
Coordinates: 34.6910465, 135.5091563

![brooklyn_roasting_company_kitahama.jpg](Brooklyn%20Roasting%20Company%20Kitahama%20brooklynroas012ff97af0/brooklyn_roasting_company_kitahama.jpg)
