# Universal Studios Japan flagship day

Group: Osaka
Day: Day 14
Type: Theme Park
Notes: 08:00-21:00 — Hit Super Nintendo World at rope drop, chase Jujutsu Kaisen XR ride, and close with Night Parade. JR Yumesaki Line to Universal City. Enter park 07:30 with early-entry Express Pass 7. Booking: Purchase USJ tickets + Express Pass (type 7) three months out; reserve Kinopio’s Café lunch. With You + Nana Approx spend £281.08 Bring power bank & wearable wristband for Power-Up Band challenges.
Visited: No

[Address: 2-chōme-1-33 Sakurajima, Konohana Ward, Osaka, 554-0031, Japan](https://maps.google.com/?cid=3892796888607511210)
Rating: 4.5 (140432 reviews)
Phone: +81 570-200-606
Website: https://www.usj.co.jp/web/ja/jp
Coordinates: 34.6656768, 135.4323185

![universal_studios_japan_flagship_day.jpg](Universal%20Studios%20Japan%20flagship%20day%20universalstu01a04d10b1/universal_studios_japan_flagship_day.jpg)
