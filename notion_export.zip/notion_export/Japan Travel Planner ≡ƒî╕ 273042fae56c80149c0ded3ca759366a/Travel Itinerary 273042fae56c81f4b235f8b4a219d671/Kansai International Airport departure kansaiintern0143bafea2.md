# Kansai International Airport departure

Group: Osaka
Day: Day 17
Type: Departure
Notes: 18:00-23:00 — Check in early, enjoy KIX Lounge showers, and savour final takoyaki before overnight flight home. Hotel limo or Nankai Rapi:t to KIX (~45 min). Arrive 3 hours pre-flight for tax-free refund pickup. Booking: Confirm airline upgrade waitlist; pre-book KIX lounge seats via Priority Pass. With You + Nana Hand-carry matcha and sake; ensure liquids follow allowance.
Visited: No

[Address: Terminal 1, Osaka, Japan](https://maps.google.com/?cid=12104414214768042484)
Coordinates: 34.4348282, 135.2446195

![kansai_international_airport_departure.jpg](Kansai%20International%20Airport%20departure%20kansaiintern0143bafea2/kansai_international_airport_departure.jpg)
