# Riverside soba at Arashiyama Yoshimura

Group: Kyoto
Day: Day 3
Type: Food
Notes: 11:00-12:00 — Warm up with handmade soba and tempura while overlooking Togetsukyo Bridge from tatami seating. Add name to queue by 10:30; ask for second-floor window seat. Average spend ¥2,000 pp. Booking: No reservations; request English menu for seasonal soba. With You + Nana Approx spend £21.62 Order yuba sashimi sampler to share.
Visited: No

[Address: Japan, 〒616-8385 京都府京都市右京区嵯峨天龍寺芒ノ馬場町３](https://maps.google.com/?cid=14941654592724285625)
Rating: 4.2 (2442 reviews)
Phone: +81 75-863-5700
Website: https://yoshimura-gr.com/arashiyama/
Coordinates: 35.0136474, 135.6772645

![riverside_soba_at_arashiyama_yoshimura.jpg](Riverside%20soba%20at%20Arashiyama%20Yoshimura%20riversidesob01fb46702f/riverside_soba_at_arashiyama_yoshimura.jpg)
