# Kimono Forest at Randen Arashiyama

Group: Kyoto
Day: Day 3
Type: Photo Spot
Notes: 12:10-12:40 — Wander through 600 illuminated kimono poles—perfect midday photo op before heading south. Free entry beside Randen tram station. Capture boomerang videos under the sky projection well. Booking: None. With You + Nana Pick favourite pattern for future custom yukata order.
Visited: No

[Address: 20-2 Sagatenryūji Tsukurimichichō, Ukyo Ward, Kyoto, 616-8384, Japan](https://maps.google.com/?cid=14328627673236365801)
Rating: 4.2 (1914 reviews)
Phone: +81 75-882-5110
Website: http://www.kyotoarashiyama.jp/about
Coordinates: 35.0152682, 135.6783695

![kimono_forest_at_randen_arashiyama.jpg](Kimono%20Forest%20at%20Randen%20Arashiyama%20kimonoforest011b62aa91/kimono_forest_at_randen_arashiyama.jpg)
