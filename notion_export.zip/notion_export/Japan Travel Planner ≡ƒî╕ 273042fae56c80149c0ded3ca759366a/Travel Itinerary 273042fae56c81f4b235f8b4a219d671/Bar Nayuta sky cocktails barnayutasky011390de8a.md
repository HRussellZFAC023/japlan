# Bar Nayuta sky cocktails

Group: Osaka
Day: Day 15
Type: Nightlife
Notes: 23:45-01:00 — Wind down with rooftop mixology featuring yuzu gin fizzes and dessert cocktails overlooking Osaka Castle lights. 5-minute taxi from karaoke. Dress smart-casual; limited seating at counter. Booking: Reserve 23:45 slot; request custom drink named “Japlan Nova”. With You + Nana + Nicole + Ken Approx spend £86.49 Bring small thank-you gifts for bartenders (Aussie chocolate).
Visited: No

[Address: Japan, 〒542-0086 Osaka, Chuo Ward, Nishishinsaibashi, 1-chōme−6−１７ マリオビル5F](https://maps.google.com/?cid=8702241179377055165)
Rating: 4.7 (1212 reviews)
Phone: +81 6-6210-3615
Website: http://bar-nayuta.com/
Coordinates: 34.672034, 135.498379

![bar_nayuta_sky_cocktails.png](Bar%20Nayuta%20sky%20cocktails%20barnayutasky011390de8a/bar_nayuta_sky_cocktails.png)
