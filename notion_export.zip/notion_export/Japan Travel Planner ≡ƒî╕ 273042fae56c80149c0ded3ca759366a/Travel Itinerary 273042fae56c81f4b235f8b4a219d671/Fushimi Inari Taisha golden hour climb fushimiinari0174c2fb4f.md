# Fushimi Inari Taisha golden hour climb

Group: Kyoto
Day: Day 3
Type: Culture
Notes: 16:00-18:00 — Trace thousands of vermilion torii, pausing at Yotsutsuji for Kyoto panorama as lanterns begin to glow. JR Nara Line to Inari (30 min). Climb to summit (~90 min round trip) with kitsune snack stops. Booking: None; consider renting kimono early morning for evening return photos. With You + Nana Write shared wish on torii ema for upcoming Tokyo meet-ups.
Visited: No

[Address: 68 Fukakusa Yabunouchichō, Fushimi Ward, Kyoto, 612-0882, Japan](https://maps.google.com/?cid=8870624639634301673)
Rating: 4.6 (80845 reviews)
Phone: +81 75-641-7331
Website: https://inari.jp/
Coordinates: 34.9676945, 135.7791876

![fushimi_inari_taisha_golden_hour_climb.jpg](Fushimi%20Inari%20Taisha%20golden%20hour%20climb%20fushimiinari0174c2fb4f/fushimi_inari_taisha_golden_hour_climb.jpg)
