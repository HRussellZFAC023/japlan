# Hirakata T-SITE cowork catch-up

Group: Hirakata
Day: Day 12
Type: Work Base
Notes: 08:30-11:30 — Dial back into work mode, archive Tokyo photos, and prep Osaka birthday logistics alongside Nana. Book day desk again; bring souvenirs for Nana’s colleagues. Booking: Consider 5-day pass if returning later. With You + Nana (working) Approx spend £8.92 Ship Nicole & Ken’s leftover gifts via Yamato.
Visited: No

[Address: 12-２ Okahigashichō, Hirakata, Osaka 573-0032, Japan](https://maps.google.com/?cid=17127482803001824153)
Rating: 3.9 (6056 reviews)
Phone: +81 72-844-9000
Website: https://store.tsite.jp/hirakata/
Coordinates: 34.8158936, 135.6497036

![hirakata_t_site_cowork_catch_up.jpg](Hirakata%20T-SITE%20cowork%20catch-up%20hirakatatsit012f1f4c38/hirakata_t_site_cowork_catch_up.jpg)
