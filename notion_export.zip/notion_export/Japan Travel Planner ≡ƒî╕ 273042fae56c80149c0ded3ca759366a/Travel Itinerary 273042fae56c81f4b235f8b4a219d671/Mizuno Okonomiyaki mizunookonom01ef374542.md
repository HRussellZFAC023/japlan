# Mizuno Okonomiyaki

Group: Osaka
Day: Day 1
Type: Food
Notes: 19:00-20:30 — Celebrate night one with caramelised okonomiyaki on a teppan counter, pairing yuzu highballs with the flagship yam batter. Queue likely ~30 minutes; add name at 18:30 then explore Hozenji Yokocho until called. Order “Yamaimo-yaki” and seasonal special. Booking: No reservations; cash-focused (¥2,500 pp). With You + Nana Approx spend £27.03 Request English menu for limited-time toppings.
Visited: No

[Address: 1-chōme-4-15 Dōtonbori, Chuo Ward, Osaka, 542-0071, Japan](https://maps.google.com/?cid=14993068628475195202)
Rating: 3.8 (2948 reviews)
Phone: +81 6-6212-6360
Website: https://mizuno.gorp.jp/
Coordinates: 34.6683548, 135.5032226

![mizuno_okonomiyaki.jpg](Mizuno%20Okonomiyaki%20mizunookonom01ef374542/mizuno_okonomiyaki.jpg)
