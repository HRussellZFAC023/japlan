# Kuzuha Mall late-night prep run

Group: Hirakata
Day: Day 8
Type: Shopping
Notes: 20:15-21:30 — Final stop for Heattech, birthday décor, and Shinkansen snacks. Keihan line 3 minutes from Hirakatashi. Visit Loft + Kaldi Coffee Farm for treats. Booking: None. With You + Nana Approx spend £64.86 Print Tokyo itinerary at Aeon copy station if needed.
Visited: No

[Address: 15-1 Kuzuhahanazonochō, Hirakata, Osaka 573-1121, Japan](https://maps.google.com/?cid=18201673667111364488)
Rating: 3.9 (6325 reviews)
Phone: +81 72-866-3300
Website: http://kuzuha-mall.com/
Coordinates: 34.8615018, 135.6773988

![kuzuha_mall_late_night_prep_run.jpg](Kuzuha%20Mall%20late-night%20prep%20run%20kuzuhamallla01b543d537/kuzuha_mall_late_night_prep_run.jpg)
