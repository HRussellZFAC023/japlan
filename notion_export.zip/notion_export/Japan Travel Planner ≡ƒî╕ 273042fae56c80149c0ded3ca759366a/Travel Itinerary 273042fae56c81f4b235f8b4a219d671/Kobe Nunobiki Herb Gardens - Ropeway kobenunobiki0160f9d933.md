# Kobe Nunobiki Herb Gardens & Ropeway

Group: Kobe
Day: Day 13
Type: Nature
Notes: 09:30-12:00 — Glide up the ropeway for panoramic views and wander fragrant greenhouses with seasonal blooms. JR rapid to Shin-Kobe (30 min). Ropeway combo ticket ¥1,800; arrive early for crowd-free photos. Booking: Purchase e-tickets online for express entry. With You + Nana Approx spend £19.46 Try herb soft serve at summit café.
Visited: No

[Address: 1-chōme-4-3 Kitanochō, Chuo Ward, Kobe, Hyogo 650-0002, Japan](https://maps.google.com/?cid=9393563791333494613)
Rating: 4.5 (5426 reviews)
Phone: +81 78-271-1160
Website: https://www.kobeherb.com/
Coordinates: 34.70442750000001, 135.1938755

![kobe_nunobiki_herb_gardens___ropeway.jpg](Kobe%20Nunobiki%20Herb%20Gardens%20-%20Ropeway%20kobenunobiki0160f9d933/kobe_nunobiki_herb_gardens___ropeway.jpg)
