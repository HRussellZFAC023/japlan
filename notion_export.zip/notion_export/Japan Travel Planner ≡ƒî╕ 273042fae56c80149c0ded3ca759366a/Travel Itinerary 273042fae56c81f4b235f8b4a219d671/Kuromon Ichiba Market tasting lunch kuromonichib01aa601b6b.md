# Kuromon Ichiba Market tasting lunch

Group: Osaka
Day: Day 2
Type: Food
Notes: 13:15-14:30 — Grazing lunch of toro nigiri, charcoal-grilled scallops, and strawberry daifuku while chatting with fishmongers. 5-minute walk to Kuromon. Bring cash for stall snacks; aim for 6-8 bites (~¥3,000 pp). Booking: Optional: pre-book Kuromon tasting tour for insider stalls. With You + Nana Approx spend £32.43 Pick up fruit gift for Nana’s parents.
Visited: No

[Address: 2 Chome-21 Nipponbashi, Chuo Ward, Osaka, 542-0073, Japan](https://maps.google.com/?cid=12402117845945925953)
Rating: 4.1 (19224 reviews)
Website: https://kuromon.com/jp/
Coordinates: 34.6653529, 135.5062406

![kuromon_ichiba_market_tasting_lunch.jpg](Kuromon%20Ichiba%20Market%20tasting%20lunch%20kuromonichib01aa601b6b/kuromon_ichiba_market_tasting_lunch.jpg)
