# Kinkaku-ji (Golden Pavilion)

Group: Kyoto
Day: Day 6
Type: Culture
Notes: 08:30-09:30 — Glimpse the shimmering pavilion mirrored in Kyōko-chi pond just as the sun illuminates autumn leaves. Keihan to Demachiyanagi → bus 204 (35 min). Purchase ¥500 tickets at gate; follow one-way path. Booking: No reservations; arrive before tour buses. With You + Nana Approx spend £5.41 Pick up matcha soft serve at exit if lines are short.
Visited: No

[Address: 1 Kinkakujichō, Kita Ward, Kyoto, 603-8361, Japan](https://maps.google.com/?cid=1073025677330113631)
Rating: 4.5 (61940 reviews)
Phone: +81 75-461-0013
Website: https://www.shokoku-ji.jp/kinkakuji/
Coordinates: 35.03937, 135.7292431

![kinkaku_ji__golden_pavilion.jpg](Kinkaku-ji%20-Golden%20Pavilion-%20kinkakujigol01792f66cf/kinkaku_ji__golden_pavilion.jpg)
