# Camellia GARDEN tea ceremony

Group: Kyoto
Day: Day 6
Type: Experience
Notes: 11:30-12:30 — Hands-on tea ceremony in a hidden garden near Ninenzaka, blending cultural insight with meditative calm. Taxi from Ryōan-ji to Ninenzaka (20 min). Arrive 10 minutes early for optional kimono dressing. Booking: Book private session (¥6,000 pp) via camellia-tea-ceremony.com; request English host Nozomi. With You + Nana Approx spend £64.86 Bring socks for tatami; photography allowed after ceremony.
Visited: No

[Address: 18 Ryōanji Ikenoshitachō, Ukyo Ward, Kyoto, 616-8003, Japan](https://maps.google.com/?cid=9161111180576021376)
Rating: 4.9 (149 reviews)
Phone: +81 70-5656-7808
Website: http://www.tea-kyoto.com/
Coordinates: 35.0316667, 135.7194474

![camellia_garden_tea_ceremony.jpg](Camellia%20GARDEN%20tea%20ceremony%20camelliagard011571417f/camellia_garden_tea_ceremony.jpg)
