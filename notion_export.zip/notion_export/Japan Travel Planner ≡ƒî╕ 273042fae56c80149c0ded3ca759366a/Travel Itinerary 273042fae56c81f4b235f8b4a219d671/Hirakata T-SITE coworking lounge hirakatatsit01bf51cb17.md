# Hirakata T-SITE coworking lounge

Group: Hirakata
Day: Day 5
Type: Work Base
Notes: 08:30-12:00 — Settle into T-SITE’s airy 4F coworking zone with killer library aesthetics while Nana logs into the office nearby. 5-minute walk from Hirakatashi Station. Day pass ¥1,650 with unlimited drip coffee. Booking: Reserve desk via Kansai Cowork app; request window seats. With You + Nana (working) Approx spend £8.92 Print Disney/USJ booking confirmations using onsite printers.
Visited: No

[Address: 12-２ Okahigashichō, Hirakata, Osaka 573-0032, Japan](https://maps.google.com/?cid=17127482803001824153)
Rating: 3.9 (6056 reviews)
Phone: +81 72-844-9000
Website: https://store.tsite.jp/hirakata/
Coordinates: 34.8158936, 135.6497036

![hirakata_t_site_coworking_lounge.jpg](Hirakata%20T-SITE%20coworking%20lounge%20hirakatatsit01bf51cb17/hirakata_t_site_coworking_lounge.jpg)
