# W Osaka check-in & suite styling

Group: Osaka
Day: Day 15
Type: Lodging
Notes: 14:00-15:00 — Secure a Marvelous Suite for party-ready lighting, stash decorations, and arrange welcome amenities. Check-in early via Marriott Bonvoy elite chat; request high-floor city view and extra vanity mirrors. Booking: Stay Nov 28-30; add birthday amenity + late checkout on 30 Nov. With You (setup) + Nana after work + Nicole & Ken (guest access) Approx spend £513.51 Set up Polaroid guest book & confetti balloons before guests arrive.
Visited: No

[Address: 4-chōme-1-3 Minamisenba, Chuo Ward, Osaka, 542-0081, Japan](https://maps.google.com/?cid=2705746213831136029)
Rating: 4.2 (1662 reviews)
Phone: +81 6-6484-5355
Website: https://www.marriott.com/en-us/hotels/osaow-w-osaka/overview/?scid=f2ae0541-1279-4f24-b197-a979c79310b0
Coordinates: 34.6778348, 135.5000826

![w_osaka_check_in___suite_styling.jpg](W%20Osaka%20check-in%20-%20suite%20styling%20wosakachecki018feface4/w_osaka_check_in___suite_styling.jpg)
