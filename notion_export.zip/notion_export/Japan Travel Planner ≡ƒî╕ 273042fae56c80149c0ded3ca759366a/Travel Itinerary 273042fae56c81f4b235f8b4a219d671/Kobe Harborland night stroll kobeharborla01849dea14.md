# Kobe Harborland night stroll

Group: Kobe
Day: Day 13
Type: Night Stroll
Notes: 19:00-20:30 — Capture mosaic lights, ride the Ferris wheel if energy allows, and share harbourfront desserts. JR to Kobe Station; 5-minute walk. Check Luminarie schedule for possible early displays. Booking: None. With You + Nana Approx spend £10.81 Try Godiva hot chocolate for warm hands.
Visited: No

[Address: 1 Chome-7 Higashikawasakicho, Chuo Ward, Kobe, Hyogo 650-0044, Japan](https://maps.google.com/?cid=12749193704110128037)
Rating: 4.2 (10040 reviews)
Phone: +81 78-360-3639
Website: https://www.harborland.co.jp/
Coordinates: 34.6800711, 135.1835143

![kobe_harborland_night_stroll.jpg](Kobe%20Harborland%20night%20stroll%20kobeharborla01849dea14/kobe_harborland_night_stroll.jpg)
