# Hirakata T-SITE cowork reset

Group: Hirakata
Day: Day 8
Type: Work Base
Notes: 08:30-11:30 — Return to favourite desks for focus time, finalise Tokyo to-do lists, and sync with friends online. Grab corner booths with power outlets; schedule midday break at 11:30. Booking: Reuse multi-day pass for coworking discount. With You + Nana Approx spend £8.92 Ship Kyoto purchases via Yamato counter downstairs.
Visited: No

[Address: 12-２ Okahigashichō, Hirakata, Osaka 573-0032, Japan](https://maps.google.com/?cid=17127482803001824153)
Rating: 3.9 (6056 reviews)
Phone: +81 72-844-9000
Website: https://store.tsite.jp/hirakata/
Coordinates: 34.8158936, 135.6497036

![hirakata_t_site_cowork_reset.jpg](Hirakata%20T-SITE%20cowork%20reset%20hirakatatsit01d46c4f37/hirakata_t_site_cowork_reset.jpg)
