# Hotel Agora Osaka Moriguchi

Group: Osaka (Keihan Line)
Day: Day 1
Type: Lodging
Notes: 12:45-13:30 — Check into a sleek Keihan-line base so Nana can commute easily on work days while you explore nearby neighbourhood cafés. Haruka to Tennoji (45 min) → Osaka Loop to Kyobashi → Keihan express to Moriguchishi (total ~75 min). Request corner room with river view. Booking: Reserve flexible twin (Nov 14–18, 20–22, 25–26) on official site with breakfast add-on; note late check-in if flights delay. With You + Nana Approx spend £129.73 Use luggage forwarding desk to send Kyoto overnight bag on 19 Nov.
Visited: No

[Address: 10-5 Kawaharachō, Moriguchi, Osaka 570-0038, Japan](https://maps.google.com/?cid=13148145580788093834)
Rating: 4 (2599 reviews)
Phone: +81 6-6994-1111
Website: https://www.hotelagora-moriguchi.com/
Coordinates: 34.7350206, 135.5658619

![hotel_agora_osaka_moriguchi.jpg](Hotel%20Agora%20Osaka%20Moriguchi%20hotelagoraos01cfea9e3c/hotel_agora_osaka_moriguchi.jpg)
