# Torame Yokocho night market dinner

Group: Osaka
Day: Day 12
Type: Food
Notes: 19:00-21:00 — Graze across Osaka comfort classics—takoyaki, kushikatsu, craft beer—under a retro neon arcade. Located in Namba. Reload ICOCA before arrival; mix-and-match small plates (~¥4,000 total). Booking: No bookings; arrive early to secure communal table. With You + Nana Approx spend £43.24 Scout dessert at adjoining “Electric Cafe” for matcha parfaits.
Visited: No

[Address: 2-chōme-3-15 Sennichimae, Chuo Ward, 大阪市中央区 Osaka 542-0074, Japan](https://maps.google.com/?cid=6273016228902860999)
Rating: 4 (699 reviews)
Phone: +81 6-6636-4510
Website: http://www.虎目横丁.com/
Coordinates: 34.6655521, 135.5047441

![torame_yokocho_night_market_dinner.jpg](Torame%20Yokocho%20night%20market%20dinner%20torameyokoch0195f66340/torame_yokocho_night_market_dinner.jpg)
