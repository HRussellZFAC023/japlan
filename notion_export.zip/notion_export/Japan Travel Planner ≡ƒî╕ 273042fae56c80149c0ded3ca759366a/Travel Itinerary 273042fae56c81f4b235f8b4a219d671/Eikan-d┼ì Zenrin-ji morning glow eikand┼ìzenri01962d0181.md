# Eikan-dō Zenrin-ji morning glow

Group: Kyoto
Day: Day 16
Type: Culture
Notes: 09:30-11:00 — Marvel at fiery maple reflections in the Hojo Pond and climb the Tahoto pagoda for sweeping views. Keihan from Yodoyabashi to Jingū-Marutamachi then taxi (15 min). Entry ¥1,000; illumination tickets separate. Booking: Buy advance tickets online to skip queue; bring printed QR codes. With You + Nana + Nicole + Ken Approx spend £21.62 Shoot birthday-week group photo on the Hojo Bridge.
Visited: No

[Address: 48 Eikandōchō, Sakyo Ward, Kyoto, 606-8445, Japan](https://maps.google.com/?cid=2060121541776026964)
Rating: 4.6 (8801 reviews)
Phone: +81 75-761-0007
Website: http://www.eikando.or.jp/
Coordinates: 35.0148543, 135.7941588

![eikan_dō_zenrin_ji_morning_glow.jpg](Eikan-d%C5%8D%20Zenrin-ji%20morning%20glow%20eikand%C5%8Dzenri01962d0181/eikan_d%C5%8D_zenrin_ji_morning_glow.jpg)
