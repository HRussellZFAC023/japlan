# Osaka Museum of Housing and Living

Group: Osaka
Day: Day 12
Type: Culture
Notes: 15:30-17:00 — Wander Edo-period Osaka streets recreated indoors—rent yukata for photos and learn urban history. Subway to Tenjinbashisuji 6-chome; lockers available for bags. Entry ¥600. Booking: Reserve time slot online (English site) to skip queue. With You + Nana Approx spend £10.81 Add optional kimono rental (~¥500) for photos.
Visited: No

[Address: Japan, 〒530-0041 Osaka, Kita Ward, Tenjinbashi, 6-chōme−4−２０ 大阪市立住まい情報センタービル 8F](https://maps.google.com/?cid=10674462834411964257)
Rating: 4.2 (7776 reviews)
Phone: +81 6-6242-1170
Website: https://www.osaka-angenet.jp/konjyakukan/
Coordinates: 34.71034059999999, 135.5113276

![osaka_museum_of_housing_and_living.jpg](Osaka%20Museum%20of%20Housing%20and%20Living%20osakamuseumo0129ade36c/osaka_museum_of_housing_and_living.jpg)
