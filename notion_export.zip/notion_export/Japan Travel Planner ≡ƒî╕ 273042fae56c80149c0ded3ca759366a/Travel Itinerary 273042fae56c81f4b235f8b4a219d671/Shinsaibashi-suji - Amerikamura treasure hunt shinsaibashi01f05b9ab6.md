# Shinsaibashi-suji & Amerikamura treasure hunt

Group: Osaka
Day: Day 2
Type: Shopping
Notes: 10:15-13:00 — Blend Shinsaibashi flagship finds with Amerikamura thrift gems—hunt vintage Harajuku vibes, refill skincare at @cosme, and hit Kinji for statement pieces. Walk from Kitahama via Midosuji (15 min). Use lockers at Shinsaibashi Station to store purchases before lunch. Booking: None; map favourite boutiques in advance on shared Google Map. With You + Nana Approx spend £81.08 Drop by WEGO, BAPE, and vinyl at Timebomb Records.
Visited: No

[Address: 2-chōme-2-22 Shinsaibashisuji, Chuo Ward, Osaka, 542-0085, Japan](https://maps.google.com/?cid=7087755665176380195)
Rating: 4.3 (19750 reviews)
Phone: +81 6-6211-1114
Website: https://www.shinsaibashi.or.jp/
Coordinates: 34.6710169, 135.5013394

![shinsaibashi_suji___amerikamura_treasure_hunt.jpg](Shinsaibashi-suji%20-%20Amerikamura%20treasure%20hunt%20shinsaibashi01f05b9ab6/shinsaibashi_suji___amerikamura_treasure_hunt.jpg)
