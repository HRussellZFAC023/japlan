# Kōdai-ji night illumination

Group: Kyoto
Day: Day 16
Type: Culture
Notes: 18:00-19:30 — Nighttime light-up across Zen gardens and bamboo grove, culminating in mirror pond projections. Taxi from Tofuku-ji (15 min). Evening entry ¥1,000; ends 21:30. Booking: Buy combo ticket with Entoku-in for extra installations. With You + Nana + Nicole + Ken Approx spend £21.62 Return to Osaka via Keihan Gion-Shijo after illumination.
Visited: No

[Address: Japan, 〒605-0825 Kyoto, Higashiyama Ward, Shimokawarachō, 高台寺下河原町５２６](https://maps.google.com/?cid=2616919559259342976)
Rating: 4.4 (9204 reviews)
Phone: +81 75-561-9966
Website: https://www.kodaiji.com/
Coordinates: 35.0007687, 135.7812718

![kōdai_ji_night_illumination.jpg](K%C5%8Ddai-ji%20night%20illumination%20k%C5%8Ddaijinight01296fabf4/k%C5%8Ddai_ji_night_illumination.jpg)
