# Gokurakuyu Hirakata evening soak

Group: Hirakata
Day: Day 5
Type: Wellness
Notes: 18:30-20:00 — Reward the workday with rotenburo and carbonated baths at the local sentō/spa complex. Short taxi from station (~¥700). Bring onsen kit; tattoos require cover stickers (available at front desk). Booking: No booking needed; entry ¥850 + ¥220 towel rental. With You + Nana Approx spend £11.57 Try the salt sauna and schedule shoulder massage (+¥2,000).
Visited: No

[Address: 3-chōme-8-1 Shōdaitajika, Hirakata, Osaka 573-1132, Japan](https://maps.google.com/?cid=7875082954910224352)
Rating: 3.8 (1657 reviews)
Phone: +81 72-867-4126
Website: https://www.gokurakuyu.com/hirakata/hirakata.html
Coordinates: 34.8472568, 135.693945

![gokurakuyu_hirakata_evening_soak.jpg](Gokurakuyu%20Hirakata%20evening%20soak%20gokurakuyuhi01db8a3d94/gokurakuyu_hirakata_evening_soak.jpg)
