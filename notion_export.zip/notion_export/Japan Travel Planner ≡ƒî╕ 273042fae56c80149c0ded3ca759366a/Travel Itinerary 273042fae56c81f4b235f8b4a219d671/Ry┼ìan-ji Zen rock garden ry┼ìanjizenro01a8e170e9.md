# Ryōan-ji Zen rock garden

Group: Kyoto
Day: Day 6
Type: Culture
Notes: 09:45-10:30 — Contemplate the famed 15-stone karesansui garden in a serene morning setting. Walk 15 minutes from Kinkaku-ji. Entry ¥500; remove shoes when entering the temple hall. Booking: None. With You + Nana Approx spend £5.41 Pair with nearby yudofu shop if craving a warm snack.
Visited: No

[Address: 13 Ryōanji Goryōnoshitachō, Ukyo Ward, Kyoto, 616-8001, Japan](https://maps.google.com/?cid=16261116435795248450)
Rating: 4.5 (10281 reviews)
Phone: +81 75-463-2216
Website: http://www.ryoanji.jp/
Coordinates: 35.0344943, 135.7182634

![ryōan_ji_zen_rock_garden.jpg](Ry%C5%8Dan-ji%20Zen%20rock%20garden%20ry%C5%8Danjizenro01a8e170e9/ry%C5%8Dan_ji_zen_rock_garden.jpg)
