# MYDO Teppanyaki birthday dinner

Group: Osaka
Day: Day 15
Type: Food
Notes: 18:30-20:30 — Table-side wagyu, flambéed seafood, and custom dessert with dual birthday shout-outs for you and Ken. Located inside W Osaka. Request private teppan counter with six seats. Booking: Pre-order cake + champagne tower; confirm shellfish allergies. With You + Nana + Nicole + Ken Approx spend £324.32 Play curated playlist through restaurant’s sound system (share via Spotify link).
Visited: No

[Address: 4-chōme-1-9 Minamisenba, Chuo Ward, Osaka, 542-0081, Japan](https://maps.google.com/?cid=4258381221987283802)
Rating: 4.3 (91 reviews)
Phone: +81 6-6484-5812
Website: https://mydo.wosaka.com/
Coordinates: 34.6776398, 135.4998937

![mydo_teppanyaki_birthday_dinner.jpg](MYDO%20Teppanyaki%20birthday%20dinner%20mydoteppanya01d68f1d2e/mydo_teppanyaki_birthday_dinner.jpg)
