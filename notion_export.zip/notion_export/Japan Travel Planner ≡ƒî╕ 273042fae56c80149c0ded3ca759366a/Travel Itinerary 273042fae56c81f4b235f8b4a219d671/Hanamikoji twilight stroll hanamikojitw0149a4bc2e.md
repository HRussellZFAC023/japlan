# Hanamikoji twilight stroll

Group: Kyoto
Day: Day 6
Type: Culture
Notes: 17:30-18:30 — Evening walk through Gion’s lantern-lit lanes hoping for a glimpse of maiko en route to engagements. 10-minute walk from ryokan. Stay respectful—no flash photography or blocking paths. Booking: Optional: book Gion cultural guide for deeper insights. With You + Nana Stop by Tatsumi Bridge for couple portraits.
Visited: No

[Address: Hanamikoji-dori, Higashiyama Ward, Kyoto, Japan](https://maps.google.com/?cid=17005749363295018432)
Coordinates: 35.0054928, 135.7752402
