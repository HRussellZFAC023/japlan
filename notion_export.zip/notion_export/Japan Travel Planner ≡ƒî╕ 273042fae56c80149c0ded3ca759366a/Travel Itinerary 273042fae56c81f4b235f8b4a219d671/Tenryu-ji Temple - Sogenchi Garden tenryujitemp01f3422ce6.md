# Tenryu-ji Temple & Sogenchi Garden

Group: Kyoto
Day: Day 3
Type: Culture
Notes: 07:45-09:15 — Explore UNESCO Zen gardens glowing with momiji, and sip matcha overlooking the koi pond. Entrance ¥500 + ¥300 for garden. Use north gate to exit directly into bamboo grove. Booking: Reserve shojin-ryori breakfast at Shigetsu for 8:00 seating if desired. With You + Nana Approx spend £8.65 Check foliage reports for peak colour adjustments.
Visited: No

[Address: Japan, 〒616-8385 京都府京都市右京区嵯峨天龍寺芒ノ馬場町６８](https://maps.google.com/?cid=14815785984447432896)
Rating: 4.4 (15128 reviews)
Phone: +81 75-881-1235
Website: https://www.tenryuji.com/
Coordinates: 35.0158379, 135.6737654

![tenryu_ji_temple___sogenchi_garden.jpg](Tenryu-ji%20Temple%20-%20Sogenchi%20Garden%20tenryujitemp01f3422ce6/tenryu_ji_temple___sogenchi_garden.jpg)
