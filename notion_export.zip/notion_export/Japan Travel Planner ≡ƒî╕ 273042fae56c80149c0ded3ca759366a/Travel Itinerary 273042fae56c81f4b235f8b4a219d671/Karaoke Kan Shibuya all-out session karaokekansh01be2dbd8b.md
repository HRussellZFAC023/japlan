# Karaoke Kan Shibuya all-out session

Group: Tokyo
Day: Day 10
Type: Nightlife
Notes: 20:00-22:30 — Sing through anime themes, K-pop, and nostalgic hits with drink package and custom cake delivery. Reserve party room with neon lighting; bring Polaroid for instant keepsakes. Booking: Book 3-hour plan with unlimited soft drinks + two cocktails per person. With You + Nana + Nicole + Ken Approx spend £97.30 Queue duet playlist curated earlier in Spotify.
Visited: No

[Address: Japan, 〒150-0042 Tokyo, Shibuya, Udagawachō, 30−８ K&F ビル](https://maps.google.com/?cid=7596898140513591090)
Rating: 3.5 (138 reviews)
Phone: +81 3-3462-0785
Website: https://karaokekan.jp/shop/detail/30
Coordinates: 35.6608934, 139.6981704

![karaoke_kan_shibuya_all_out_session.png](Karaoke%20Kan%20Shibuya%20all-out%20session%20karaokekansh01be2dbd8b/karaoke_kan_shibuya_all_out_session.png)
