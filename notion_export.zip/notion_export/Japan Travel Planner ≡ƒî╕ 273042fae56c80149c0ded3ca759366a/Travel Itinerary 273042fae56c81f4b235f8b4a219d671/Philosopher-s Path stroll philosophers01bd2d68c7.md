# Philosopher’s Path stroll

Group: Kyoto
Day: Day 16
Type: Nature
Notes: 11:00-12:00 — Leisurely walk along the canal beneath amber leaves, stopping for craft boutiques and gelato. Start near Eikan-dō and head north; peek into artisanal shops like Ginkaku-ji Seseragi. Booking: None. With You + Nana + Nicole + Ken Approx spend £10.81 Grab seasonal gelato at Sfera Bar Satén en route.
Visited: No

[Address: Tetsugaku No Michi, Sakyo Ward, Kyoto, Japan](https://maps.google.com/?cid=13093296689021343783)
Coordinates: 35.0214532, 135.7942948

![philosopher_s_path_stroll.jpg](Philosopher-s%20Path%20stroll%20philosophers01bd2d68c7/philosopher_s_path_stroll.jpg)
