# OMO7 Osaka by Hoshino Resorts check-in

Group: Osaka
Day: Day 7
Type: Lodging
Notes: 16:00-16:30 — Shift to a design-forward stay with tatami lounges, onsen-style baths, and Osaka-focused concierge tours. JR Kyoto Line to Tennoji (~45 min). Request skyline view room; enjoy welcome sweets. Booking: Stay Nov 20 only; add breakfast buffet and sauna package. With You + Nana Approx spend £172.97 Ask concierge to arrange Friday morning shuttle to Hirakata.
Visited: No

[Address: 3-chōme-16-30 Ebisunishi, Naniwa Ward, Osaka, 556-0003, Japan](https://maps.google.com/?cid=10904178204825139386)
Rating: 4.2 (1842 reviews)
Phone: +81 50-3134-8095
Website: https://hoshinoresorts.com/ja/hotels/omo7osaka/?utm_source=google&utm_medium=mybusiness
Coordinates: 34.6508135, 135.5018895

![omo7_osaka_by_hoshino_resorts_check_in.jpg](OMO7%20Osaka%20by%20Hoshino%20Resorts%20check-in%20omo7osakabyh0107aec2ed/omo7_osaka_by_hoshino_resorts_check_in.jpg)
