# Disney Ambassador Hotel lounge reset

Group: Tokyo
Day: Day 11
Type: Lodging
Notes: 13:30-15:00 — Afternoon tea at Hyperion Lounge to recharge mid-park with seasonal desserts and photo ops. 5-minute walk from park entrance; deposit bags with bell desk before lounge visit. Booking: Reserve 14:00 seating via official app; note birthday celebration. With You + Nana + Nicole + Ken Approx spend £86.49 Collect exclusive hotel pin for keepsake board.
Visited: No

[Address: 2-11 Maihama, Urayasu, Chiba 279-8522, Japan](https://maps.google.com/?cid=6044710685353048397)
Rating: 4.5 (5989 reviews)
Phone: +81 47-305-1111
Website: https://www.tokyodisneyresort.jp/hotel/dah/
Coordinates: 35.6332807, 139.8877219

![disney_ambassador_hotel_lounge_reset.jpg](Disney%20Ambassador%20Hotel%20lounge%20reset%20disneyambass0140c3ad9c/disney_ambassador_hotel_lounge_reset.jpg)
