# Kyoto Yakiniku Hiro (Shijo Kiyamachi)

Group: Kyoto
Day: Day 7
Type: Food
Notes: 12:00-13:30 — Indulge in wagyu lunch set with river views before heading back to Osaka. Reserve tatami booth; lunch set ~¥3,500 pp. Use luggage storage at ryokan until departure. Booking: Book via TableCheck; note allergy preferences. With You + Nana Approx spend £37.84 Split premium platter to sample A5 cuts.
Visited: No

[Address: 674-2 Kamiyachō, Nakagyo Ward, Kyoto, 600-8001, Japan](https://maps.google.com/?cid=3280333615075260841)
Rating: 4.2 (490 reviews)
Phone: +81 75-251-1129
Website: https://www.instagram.com/yakinikuhiro/
Coordinates: 35.0043578, 135.7704222

![kyoto_yakiniku_hiro__shijo_kiyamachi.jpg](Kyoto%20Yakiniku%20Hiro%20-Shijo%20Kiyamachi-%20kyotoyakinik010e907c3a/kyoto_yakiniku_hiro__shijo_kiyamachi.jpg)
