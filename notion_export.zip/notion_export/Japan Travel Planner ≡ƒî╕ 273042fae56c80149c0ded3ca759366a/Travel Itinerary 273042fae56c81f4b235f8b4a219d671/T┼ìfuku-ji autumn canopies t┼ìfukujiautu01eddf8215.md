# Tōfuku-ji autumn canopies

Group: Kyoto
Day: Day 16
Type: Culture
Notes: 14:30-16:00 — Stroll across Tsutenkyo Bridge for jaw-dropping maple valley views and temple gardens. Keihan to Tofukuji Station; timed entry queue moves quickly (~20 min). Booking: Purchase timed tickets online if available; otherwise buy on arrival (¥1,000). With You + Nana + Nicole + Ken Approx spend £21.62 Visit Kaisando for quieter contemplation.
Visited: No

[Address: 15-chōme-778 Honmachi, Higashiyama Ward, Kyoto, 605-0981, Japan](https://maps.google.com/?cid=7117677159742707137)
Rating: 4.5 (10246 reviews)
Phone: +81 75-561-0087
Website: https://tofukuji.jp/
Coordinates: 34.976025, 135.7737627

![tōfuku_ji_autumn_canopies.jpg](T%C5%8Dfuku-ji%20autumn%20canopies%20t%C5%8Dfukujiautu01eddf8215/t%C5%8Dfuku_ji_autumn_canopies.jpg)
