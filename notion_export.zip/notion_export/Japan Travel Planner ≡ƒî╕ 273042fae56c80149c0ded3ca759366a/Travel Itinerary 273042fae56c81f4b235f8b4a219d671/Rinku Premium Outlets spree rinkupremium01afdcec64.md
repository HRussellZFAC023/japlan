# Rinku Premium Outlets spree

Group: Izumisano
Day: Day 17
Type: Shopping
Notes: 13:00-16:00 — Outlet hop for last-minute gifts—Onitsuka Tiger, Coach, Nintendo Tokyo satellite—and sunset pier views. JR rapid or Nankai to Rinku-Town (40 min). Use hands-free delivery counter for extra bags. Booking: Download coupon QR via official site for extra 10% savings. With You + Nana Approx spend £162.16 Ride Rinku OOTD Ferris wheel if time allows.
Visited: No

[Address: 3-28 Rinkūōraiminami, Izumisano, Osaka 598-8508, Japan](https://maps.google.com/?cid=14141131390446530690)
Rating: 4.1 (14913 reviews)
Phone: +81 50-1721-5234
Website: https://www.premiumoutlets.co.jp/rinku/
Coordinates: 34.4064643, 135.2954403

![rinku_premium_outlets_spree.jpg](Rinku%20Premium%20Outlets%20spree%20rinkupremium01afdcec64/rinku_premium_outlets_spree.jpg)
