# Shibuya Sky golden hour meet-up

Group: Tokyo
Day: Day 9
Type: Viewpoint
Notes: 17:00-18:30 — Meet James for panoramic city views as the scramble lights up below—capture drone-like shots from the helipad deck. Pre-book 17:00 entry (¥2,200). Lockers for bags; no tripods allowed but smartphone gimbals ok. Booking: Purchase tickets 2 months ahead; reserve Sky Gallery café seating. With You + Nana + Nicole + Ken + James Approx spend £59.46 Coordinate surprise mini cake for James via café staff.
Visited: No

[Address: Japan, 〒150-6145 Tokyo, Shibuya, 2-chōme−24−１２ スクランブルスクエア 14階・45階 46階・屋上](https://maps.google.com/?cid=8067212359343678579)
Rating: 4.6 (20820 reviews)
Phone: +81 3-4221-0229
Website: https://www.shibuya-scramble-square.com/sky/
Coordinates: 35.6586719, 139.7019848

![shibuya_sky_golden_hour_meet_up.jpg](Shibuya%20Sky%20golden%20hour%20meet-up%20shibuyaskygo01cfc455f8/shibuya_sky_golden_hour_meet_up.jpg)
