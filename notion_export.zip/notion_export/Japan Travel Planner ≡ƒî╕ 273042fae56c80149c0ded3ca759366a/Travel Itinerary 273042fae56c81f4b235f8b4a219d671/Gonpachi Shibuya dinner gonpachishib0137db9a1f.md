# Gonpachi Shibuya dinner

Group: Tokyo
Day: Day 9
Type: Food
Notes: 19:00-21:00 — Izakaya feast with yakitori, sushi rolls, and sake flights inspired by Kill Bill vibes to cap the day. 10-minute walk from Shibuya Crossing. Order set menu (~¥5,000 pp) plus vegetarian sides for Ken. Booking: Reserve private tatami room for 6; mention birthdays for dessert sparklers. With You + Nana + Nicole + Ken + James Approx spend £162.16 Pay via credit card; split bill later using shared tracker.
Visited: No

[Address: Japan, 〒150-0044 Tokyo, Shibuya, Maruyamachō, 3−６ E-Space Tower, １４Ｆ フロアA](https://maps.google.com/?cid=5535728105966142773)
Rating: 4.1 (1856 reviews)
Phone: +81 50-5443-0489
Website: https://gonpachi.jp/shibuya/
Coordinates: 35.6574935, 139.6955514

![gonpachi_shibuya_dinner.jpg](Gonpachi%20Shibuya%20dinner%20gonpachishib0137db9a1f/gonpachi_shibuya_dinner.jpg)
