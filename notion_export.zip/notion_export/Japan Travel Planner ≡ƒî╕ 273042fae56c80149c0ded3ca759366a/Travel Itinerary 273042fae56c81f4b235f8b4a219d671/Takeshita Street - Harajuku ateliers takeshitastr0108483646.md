# Takeshita Street & Harajuku ateliers

Group: Tokyo
Day: Day 9
Type: Shopping
Notes: 13:30-16:30 — Hop between Laforet pop-ups, 6%DOKIDOKI, and vintage sneaker shops while trying crepes and purikura booths. Create shared AirDrop album for haul photos. Visit Moshi Moshi Box for free Wi-Fi & maps. Booking: Book 15:00 purikura slot at NOA Café for group shots. With You + Nana + Nicole + Ken Approx spend £108.11 Pick matching accessories for birthday party outfits.
Visited: No

[Address: Takeshita St, 1-chōme Jingūmae, Shibuya, Tokyo 150-0001, Japan](https://maps.google.com/?cid=14032878377351675573)
Coordinates: 35.6710335, 139.7051821

![takeshita_street___harajuku_ateliers.jpg](Takeshita%20Street%20-%20Harajuku%20ateliers%20takeshitastr0108483646/takeshita_street___harajuku_ateliers.jpg)
