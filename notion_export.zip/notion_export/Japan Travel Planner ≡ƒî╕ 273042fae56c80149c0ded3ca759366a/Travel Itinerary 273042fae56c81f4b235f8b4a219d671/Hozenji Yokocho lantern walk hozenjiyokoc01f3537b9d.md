# Hozenji Yokocho lantern walk

Group: Osaka
Day: Day 1
Type: Night Stroll
Notes: 20:30-21:15 — Wind down along the mossy alley, wash the Fudō-myōō statue for blessings, and grab warabi-mochi to-go for the train ride home. 2-minute walk from Mizuno. Keihan trains run until after midnight back to Moriguchishi (last rapid ~23:50). Booking: None. With You + Nana Approx spend £6.49 Collect omamori for safe travels + relationship luck.
Visited: No

[Address: 1 Chome-7 Namba, Chuo Ward, Osaka, 542-0076, Japan](https://maps.google.com/?cid=1940503935653472466)
Rating: 4.3 (320 reviews)
Coordinates: 34.668208, 135.5026287

![hozenji_yokocho_lantern_walk.jpg](Hozenji%20Yokocho%20lantern%20walk%20hozenjiyokoc01f3537b9d/hozenji_yokocho_lantern_walk.jpg)
