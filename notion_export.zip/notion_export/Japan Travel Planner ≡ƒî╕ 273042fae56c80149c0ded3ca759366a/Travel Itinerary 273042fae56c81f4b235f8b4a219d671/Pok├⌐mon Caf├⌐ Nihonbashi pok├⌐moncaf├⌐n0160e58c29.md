# Pokémon Café Nihonbashi

Group: Tokyo
Day: Day 10
Type: Food
Notes: 12:00-13:30 — Adorable character plates, latte art, and special edition merch with tableside Pikachu show. 5F Takashimaya annex; arrive 15 minutes early to check in. Average spend ¥3,000 pp. Booking: Reservations open exactly 31 days in advance at 18:00 JST—set reminder. With You + Nana + Nicole + Ken Approx spend £64.86 Order seasonal dessert for Ken’s birthday shout-out.
Visited: No

[Address: Japan, 〒103-0027 Tokyo, Chuo City, Nihonbashi, 2-chōme−11−２ 髙島屋S.C.東館 ５階](https://maps.google.com/?cid=4725603843889793061)
Rating: 4.2 (2747 reviews)
Phone: +81 3-6262-3439
Website: https://www.pokemon-cafe.jp/ja/cafe/
Coordinates: 35.6806385, 139.7744332

![pokémon_café_nihonbashi.jpg](Pok%C3%A9mon%20Caf%C3%A9%20Nihonbashi%20pok%C3%A9moncaf%C3%A9n0160e58c29/pok%C3%A9mon_caf%C3%A9_nihonbashi.jpg)
